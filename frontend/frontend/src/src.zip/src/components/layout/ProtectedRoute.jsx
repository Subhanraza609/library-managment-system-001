import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '../../lib/auth'

export function ProtectedRoute({ roles, children }) {
  const { isAuthenticated, role } = useAuth()
  const location = useLocation()

  if (!isAuthenticated) {
    return <Navigate to="/login" replace state={{ from: location }} />
  }

  if (roles && roles.length > 0 && !roles.includes(role)) {
    return <Navigate to="/403" replace />
  }

  return children
}
