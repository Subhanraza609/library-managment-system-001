// Role-based navigation derived from the RBAC matrix in PLAN.md §6.
// `roles: null` means visible to any authenticated user.
export const navItems = [
  { to: '/dashboard', label: 'Dashboard', roles: null },
  { to: '/members', label: 'Members', roles: ['admin'] },
  { to: '/catalog', label: 'Catalog', roles: null },
  { to: '/loans', label: 'Loans', roles: null },
  { to: '/fines', label: 'Fines', roles: null },
  { to: '/reports', label: 'Reports', roles: ['admin', 'librarian'] },
  { to: '/notifications', label: 'Reminders', roles: ['admin'] },
]

export function visibleNavItems(role) {
  return navItems.filter((item) => !item.roles || item.roles.includes(role))
}

// Roles allowed to access each protected route. `null` = any authenticated user.
export const routeRoles = {
  dashboard: null,
  members: ['admin'],
  catalog: null,
  loans: null,
  fines: null,
  reports: ['admin', 'librarian'],
  notifications: ['admin'],
}
