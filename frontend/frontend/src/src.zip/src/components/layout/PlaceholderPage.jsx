export function PlaceholderPage({ title }) {
  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="text-xl font-semibold text-gray-900 dark:text-slate-100">{title}</h1>
      <p className="mt-2 text-sm text-gray-500 dark:text-slate-400">— coming soon</p>
    </div>
  )
}
