import { Outlet, useLocation } from 'react-router-dom'
import { Sidebar } from './Sidebar'
import { Topbar } from './Topbar'

export function AppShell() {
  const location = useLocation()

  return (
    <div className="flex h-full min-h-screen bg-slate-50 dark:bg-slate-950">
      <Sidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar />
        <main className="flex-1 overflow-y-auto">
          <div
            key={location.pathname}
            className="mx-auto w-full max-w-7xl animate-fade-in p-4 md:p-6 lg:p-8"
          >
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  )
}
