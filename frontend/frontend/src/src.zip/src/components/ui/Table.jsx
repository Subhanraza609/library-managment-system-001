import { cn } from '../../lib/cn'

export function Table({ className, children, ...props }) {
  return (
    <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-card">
      <table
        className={cn('min-w-full divide-y divide-slate-200 dark:divide-slate-800 text-sm', className)}
        {...props}
      >
        {children}
      </table>
    </div>
  )
}

export function THead({ children }) {
  return <thead className="bg-slate-50 dark:bg-slate-800/60">{children}</thead>
}

export function TBody({ children }) {
  return <tbody className="divide-y divide-slate-100 dark:divide-slate-800 bg-white dark:bg-slate-900">{children}</tbody>
}

export function TR({ className, children, ...props }) {
  return (
    <tr className={cn('transition-colors hover:bg-slate-50 dark:hover:bg-slate-800/60', className)} {...props}>
      {children}
    </tr>
  )
}

export function TH({ className, children, ...props }) {
  return (
    <th
      scope="col"
      className={cn(
        'px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400',
        className,
      )}
      {...props}
    >
      {children}
    </th>
  )
}

export function TD({ className, children, ...props }) {
  return (
    <td className={cn('px-4 py-3 text-slate-700 dark:text-slate-200', className)} {...props}>
      {children}
    </td>
  )
}
