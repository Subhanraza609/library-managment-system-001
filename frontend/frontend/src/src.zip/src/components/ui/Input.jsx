import { forwardRef } from 'react'
import { cn } from '../../lib/cn'

export const Input = forwardRef(function Input(
  { className, invalid, ...props },
  ref,
) {
  return (
    <input
      ref={ref}
      aria-invalid={invalid || undefined}
      className={cn(
        'block w-full rounded-lg border-0 px-3 py-2 text-sm text-slate-900 dark:text-slate-100 shadow-sm ring-1 ring-inset transition placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:ring-2 focus:ring-inset disabled:cursor-not-allowed disabled:bg-slate-50',
        invalid
          ? 'ring-red-400 focus:ring-red-500'
          : 'ring-slate-300 dark:ring-slate-700 focus:ring-brand-600',
        className,
      )}
      {...props}
    />
  )
})
