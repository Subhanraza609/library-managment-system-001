import React from 'react'
import { cn } from '../../lib/cn'

const variants = {
  primary:
    'bg-gradient-to-tr from-brand-600 to-indigo-500 text-white shadow-md shadow-brand-500/10 hover:shadow-lg hover:shadow-brand-500/20 hover:from-brand-700 hover:to-indigo-600 focus-visible:outline-brand-600',
  accent:
    'bg-gradient-to-tr from-accent-600 to-amber-500 text-white shadow-md shadow-accent-500/10 hover:shadow-lg hover:shadow-accent-500/20 hover:from-accent-700 hover:to-amber-600 focus-visible:outline-accent-600',
  secondary:
    'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 ring-1 ring-inset ring-slate-200 dark:ring-slate-800/80 shadow-sm hover:bg-slate-50 dark:hover:bg-slate-800/60 hover:text-slate-900 focus-visible:outline-slate-400',
  danger:
    'bg-gradient-to-tr from-red-600 to-rose-500 text-white shadow-md shadow-red-500/10 hover:shadow-lg hover:shadow-red-500/20 hover:from-red-700 hover:to-rose-600 focus-visible:outline-red-600',
  ghost:
    'bg-transparent text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 focus-visible:outline-slate-400',
}

const sizes = {
  sm: 'px-3 py-1.5 text-xs',
  md: 'px-4 py-2 text-sm',
  lg: 'px-5 py-2.5 text-base',
}

export function Button({
  as: Component = 'button',
  asChild = false,
  variant = 'primary',
  size = 'md',
  type = 'button',
  className,
  disabled,
  children,
  ...props
}) {
  if (asChild && React.isValidElement(children)) {
    const child = React.Children.only(children)
    return React.cloneElement(child, {
      className: cn(
        'inline-flex items-center justify-center gap-2 rounded-lg font-medium transition-all duration-150 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50',
        variants[variant],
        sizes[size],
        className,
        child.props.className
      ),
      ...props,
      ...child.props,
    })
  }

  const isButton = Component === 'button'
  return (
    <Component
      type={isButton ? type : undefined}
      disabled={isButton ? disabled : undefined}
      className={cn(
        'inline-flex items-center justify-center gap-2 rounded-lg font-medium transition-all duration-150 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50',
        variants[variant],
        sizes[size],
        className,
      )}
      {...props}
    >
      {children}
    </Component>
  )
}
