import { useId, useRef, useState } from 'react'
import { cn } from '../../lib/cn'
import { Button } from './Button'

export function FileUpload({
  accept = 'image/*',
  label = 'Upload file',
  onSelect,
  className,
}) {
  const inputRef = useRef(null)
  const id = useId()
  const [fileName, setFileName] = useState('')

  function handleChange(e) {
    const file = e.target.files?.[0] ?? null
    setFileName(file?.name ?? '')
    onSelect?.(file)
  }

  return (
    <div className={cn('flex items-center gap-3', className)}>
      <input
        ref={inputRef}
        id={id}
        type="file"
        accept={accept}
        className="sr-only"
        onChange={handleChange}
      />
      <Button
        variant="secondary"
        size="sm"
        onClick={() => inputRef.current?.click()}
      >
        {label}
      </Button>
      <span className="truncate text-sm text-gray-500 dark:text-slate-400">
        {fileName || 'No file selected'}
      </span>
    </div>
  )
}
