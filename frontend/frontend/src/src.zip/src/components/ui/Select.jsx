import { forwardRef } from 'react'
import { cn } from '../../lib/cn'

export const Select = forwardRef(function Select(
  { className, invalid, children, ...props },
  ref,
) {
  return (
    <select
      ref={ref}
      aria-invalid={invalid || undefined}
      className={cn(
        'block w-full rounded-lg border-0 px-3 py-2 text-sm text-slate-900 dark:text-slate-100 shadow-sm ring-1 ring-inset transition focus:ring-2 focus:ring-inset disabled:cursor-not-allowed disabled:bg-slate-50',
        invalid
          ? 'ring-red-400 focus:ring-red-500'
          : 'ring-slate-300 dark:ring-slate-700 focus:ring-brand-600',
        className,
      )}
      {...props}
    >
      {children}
    </select>
  )
})
