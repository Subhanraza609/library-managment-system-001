import { Link } from 'react-router-dom'
import { Button } from '../../components/ui/Button'

export default function ForbiddenPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-gray-50 dark:bg-slate-800/60 px-4 text-center">
      <p className="text-5xl font-bold text-indigo-600">403</p>
      <h1 className="text-xl font-semibold text-gray-900 dark:text-slate-100">Access denied</h1>
      <p className="max-w-sm text-sm text-gray-500 dark:text-slate-400">
        You don&apos;t have permission to view this page.
      </p>
      <Link to="/dashboard">
        <Button>Back to dashboard</Button>
      </Link>
    </div>
  )
}
