import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import api from '../../lib/api'
import { getApiErrorMessage } from '../../lib/apiError'
import { useToast } from '../../components/ui/Toast'
import { Button } from '../../components/ui/Button'
import { Badge } from '../../components/ui/Badge'
import { Table, THead, TBody, TR, TH, TD } from '../../components/ui/Table'
import { EmptyState } from '../../components/ui/EmptyState'
import { Skeleton } from '../../components/ui/Skeleton'

function statusTone(status) {
  if (status === 'approved') return 'green'
  if (status === 'rejected') return 'red'
  if (status === 'pending') return 'yellow'
  return 'gray'
}

export default function ApprovalsPage() {
  const { toast } = useToast()
  const queryClient = useQueryClient()

  const { data, isLoading } = useQuery({
    queryKey: ['users', { status: 'pending' }],
    queryFn: () => api.get('/users', { params: { status: 'pending', page_size: 100 } }).then((r) => r.data),
  })

  const approve = useMutation({
    mutationFn: (id) => api.post(`/users/${id}/approve`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] })
      toast({ tone: 'success', title: 'User approved.' })
    },
    onError: (err) => toast({ tone: 'error', title: 'Error', description: getApiErrorMessage(err) }),
  })

  const reject = useMutation({
    mutationFn: (id) => api.post(`/users/${id}/reject`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] })
      toast({ tone: 'success', title: 'User rejected.' })
    },
    onError: (err) => toast({ tone: 'error', title: 'Error', description: getApiErrorMessage(err) }),
  })

  const pending = data?.items ?? []

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-slate-100">Pending Approvals</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-slate-400">Members awaiting account activation.</p>
        </div>
        <Link
          to="/members"
          className="text-sm font-medium text-indigo-600 hover:text-indigo-500"
        >
          ← Back to members
        </Link>
      </div>

      {isLoading ? (
        <div className="space-y-2">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </div>
      ) : pending.length === 0 ? (
        <EmptyState title="No pending approvals" description="All registrations have been reviewed." />
      ) : (
        <Table>
          <THead>
            <TR>
              <TH>Name</TH>
              <TH>Email</TH>
              <TH>Status</TH>
              <TH>Registered</TH>
              <TH>Actions</TH>
            </TR>
          </THead>
          <TBody>
            {pending.map((user) => (
              <TR key={user.id}>
                <TD className="font-medium">{user.name}</TD>
                <TD>{user.email}</TD>
                <TD>
                  <Badge tone={statusTone(user.status)}>{user.status}</Badge>
                </TD>
                <TD>{user.created_at ? new Date(user.created_at).toLocaleDateString() : '—'}</TD>
                <TD>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="primary"
                      disabled={approve.isPending || reject.isPending}
                      onClick={() => approve.mutate(user.id)}
                    >
                      Approve
                    </Button>
                    <Button
                      size="sm"
                      variant="danger"
                      disabled={approve.isPending || reject.isPending}
                      onClick={() => reject.mutate(user.id)}
                    >
                      Reject
                    </Button>
                  </div>
                </TD>
              </TR>
            ))}
          </TBody>
        </Table>
      )}
    </div>
  )
}
