import { useParams, Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import api from '../../lib/api'
import { Badge } from '../../components/ui/Badge'
import { Skeleton } from '../../components/ui/Skeleton'
import { EmptyState } from '../../components/ui/EmptyState'
import { Table, THead, TBody, TR, TH, TD } from '../../components/ui/Table'

function statusTone(status) {
  if (status === 'approved') return 'green'
  if (status === 'rejected') return 'red'
  if (status === 'pending') return 'yellow'
  if (status === 'suspended') return 'gray'
  return 'gray'
}

function roleTone(role) {
  if (role === 'admin') return 'indigo'
  if (role === 'librarian') return 'blue'
  return 'gray'
}

function loanStatusTone(status) {
  if (status === 'active') return 'blue'
  if (status === 'overdue') return 'red'
  return 'green'
}

function ProfileRow({ label, value }) {
  return (
    <div className="sm:grid sm:grid-cols-3 sm:gap-4 py-3 border-b border-gray-100 dark:border-slate-800 last:border-0">
      <dt className="text-sm font-medium text-gray-500 dark:text-slate-400">{label}</dt>
      <dd className="mt-1 text-sm text-gray-900 dark:text-slate-100 sm:col-span-2 sm:mt-0">{value ?? '—'}</dd>
    </div>
  )
}

export default function MemberDetailPage() {
  const { id } = useParams()

  const { data: userData, isLoading: userLoading } = useQuery({
    queryKey: ['user', id],
    queryFn: () => api.get(`/users/${id}`).then((r) => r.data.user),
  })

  const { data: loansData, isLoading: loansLoading } = useQuery({
    queryKey: ['member-loans', id],
    queryFn: () =>
      api
        .get(`/members/${id}/loans`)
        .then((r) => r.data)
        .catch((err) => {
          if (err?.response?.status === 404) return { items: [] }
          throw err
        }),
  })

  const loans = loansData?.items ?? []

  if (userLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-48 w-full" />
      </div>
    )
  }

  if (!userData) {
    return <EmptyState title="User not found" />
  }

  const user = userData

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-slate-100">{user.name}</h1>
        <Link
          to="/members"
          className="text-sm font-medium text-indigo-600 hover:text-indigo-500"
        >
          ← Back to members
        </Link>
      </div>

      <div className="rounded-lg bg-white dark:bg-slate-900 shadow ring-1 ring-gray-200 dark:ring-slate-800 p-6">
        <h2 className="text-base font-semibold text-gray-900 dark:text-slate-100 mb-4">Profile</h2>
        <dl>
          <ProfileRow label="Name" value={user.name} />
          <ProfileRow label="Email" value={user.email} />
          <ProfileRow
            label="Role"
            value={<Badge tone={roleTone(user.role)}>{user.role}</Badge>}
          />
          <ProfileRow
            label="Status"
            value={<Badge tone={statusTone(user.status)}>{user.status}</Badge>}
          />
          <ProfileRow label="Phone" value={user.phone} />
          <ProfileRow label="Address" value={user.address} />
          <ProfileRow
            label="Joined"
            value={user.created_at ? new Date(user.created_at).toLocaleDateString() : '—'}
          />
        </dl>
      </div>

      <div>
        <h2 className="text-base font-semibold text-gray-900 dark:text-slate-100 mb-4">Current Loans</h2>
        {loansLoading ? (
          <Skeleton className="h-32 w-full" />
        ) : loans.length === 0 ? (
          <EmptyState title="No active loans" description="This member has no current loans." />
        ) : (
          <Table>
            <THead>
              <TR>
                <TH>Book</TH>
                <TH>Borrowed</TH>
                <TH>Due</TH>
                <TH>Status</TH>
              </TR>
            </THead>
            <TBody>
              {loans.map((loan) => (
                <TR key={loan.id}>
                  <TD className="font-medium">{loan.book?.title ?? `Book #${loan.book_id}`}</TD>
                  <TD>{loan.borrowed_at ? new Date(loan.borrowed_at).toLocaleDateString() : '—'}</TD>
                  <TD>{loan.due_date ? new Date(loan.due_date).toLocaleDateString() : '—'}</TD>
                  <TD>
                    <Badge tone={loanStatusTone(loan.status)}>{loan.status}</Badge>
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>
        )}
      </div>
    </div>
  )
}
