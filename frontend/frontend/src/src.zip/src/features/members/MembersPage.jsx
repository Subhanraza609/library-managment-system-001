import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import api from '../../lib/api'
import { Button } from '../../components/ui/Button'
import { Input } from '../../components/ui/Input'
import { Select } from '../../components/ui/Select'
import { Badge } from '../../components/ui/Badge'
import { Table, THead, TBody, TR, TH, TD } from '../../components/ui/Table'
import { Pagination } from '../../components/ui/Pagination'
import { EmptyState } from '../../components/ui/EmptyState'
import { Skeleton } from '../../components/ui/Skeleton'

const ROLES = ['', 'admin', 'librarian', 'member']
const STATUSES = ['', 'pending', 'approved', 'rejected', 'suspended']

function statusTone(status) {
  if (status === 'approved') return 'green'
  if (status === 'rejected') return 'red'
  if (status === 'pending') return 'yellow'
  if (status === 'suspended') return 'gray'
  return 'gray'
}

function roleTone(role) {
  if (role === 'admin') return 'indigo'
  if (role === 'librarian') return 'blue'
  return 'gray'
}

export default function MembersPage() {
  const [page, setPage] = useState(1)
  const [role, setRole] = useState('')
  const [status, setStatus] = useState('')
  const [q, setQ] = useState('')
  const [search, setSearch] = useState('')

  const { data, isLoading } = useQuery({
    queryKey: ['users', { page, role, status, q }],
    queryFn: () =>
      api
        .get('/users', { params: { page, page_size: 20, role: role || undefined, status: status || undefined, q: q || undefined } })
        .then((r) => r.data),
    keepPreviousData: true,
  })

  function applySearch(e) {
    e.preventDefault()
    setQ(search)
    setPage(1)
  }

  function handleRoleChange(e) {
    setRole(e.target.value)
    setPage(1)
  }

  function handleStatusChange(e) {
    setStatus(e.target.value)
    setPage(1)
  }

  const items = data?.items ?? []
  const total = data?.total ?? 0
  const pageSize = data?.page_size ?? 20

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-slate-100">Members &amp; Users</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-slate-400">Manage all library accounts.</p>
        </div>
        <div className="flex gap-2">
          <Button as={Link} to="/members/approvals" variant="secondary" size="md">
            Pending Approvals
          </Button>
          <Button as={Link} to="/members/new" size="md">
            Add Staff
          </Button>
        </div>
      </div>

      <form onSubmit={applySearch} className="flex flex-wrap gap-3">
        <Input
          placeholder="Search name or email…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-64"
        />
        <Select value={role} onChange={handleRoleChange} className="w-36">
          {ROLES.map((r) => (
            <option key={r} value={r}>{r || 'All roles'}</option>
          ))}
        </Select>
        <Select value={status} onChange={handleStatusChange} className="w-40">
          {STATUSES.map((s) => (
            <option key={s} value={s}>{s || 'All statuses'}</option>
          ))}
        </Select>
        <Button type="submit" variant="secondary">Search</Button>
      </form>

      {isLoading ? (
        <div className="space-y-2">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </div>
      ) : items.length === 0 ? (
        <EmptyState title="No users found" description="Try adjusting your filters." />
      ) : (
        <>
          <Table>
            <THead>
              <TR>
                <TH>Name</TH>
                <TH>Email</TH>
                <TH>Role</TH>
                <TH>Status</TH>
                <TH>Joined</TH>
                <TH></TH>
              </TR>
            </THead>
            <TBody>
              {items.map((user) => (
                <TR key={user.id}>
                  <TD className="font-medium">{user.name}</TD>
                  <TD>{user.email}</TD>
                  <TD>
                    <Badge tone={roleTone(user.role)}>{user.role}</Badge>
                  </TD>
                  <TD>
                    <Badge tone={statusTone(user.status)}>{user.status}</Badge>
                  </TD>
                  <TD>{user.created_at ? new Date(user.created_at).toLocaleDateString() : '—'}</TD>
                  <TD>
                    <Link
                      to={`/members/${user.id}`}
                      className="text-sm font-medium text-indigo-600 hover:text-indigo-500"
                    >
                      View
                    </Link>
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>
          <Pagination page={page} pageSize={pageSize} total={total} onPageChange={setPage} />
        </>
      )}
    </div>
  )
}
