import { ProtectedRoute } from '../../components/layout/ProtectedRoute'
import { routeRoles } from '../../components/layout/navConfig'
import MembersPage from './MembersPage'
import MemberDetailPage from './MemberDetailPage'
import NewStaffPage from './NewStaffPage'
import ApprovalsPage from './ApprovalsPage'
import ProfilePage from './ProfilePage'

export const routes = [
  {
    path: '/members',
    element: (
      <ProtectedRoute roles={routeRoles.members}>
        <MembersPage />
      </ProtectedRoute>
    ),
  },
  {
    path: '/members/approvals',
    element: (
      <ProtectedRoute roles={routeRoles.members}>
        <ApprovalsPage />
      </ProtectedRoute>
    ),
  },
  {
    path: '/members/new',
    element: (
      <ProtectedRoute roles={routeRoles.members}>
        <NewStaffPage />
      </ProtectedRoute>
    ),
  },
  {
    path: '/members/:id',
    element: (
      <ProtectedRoute roles={routeRoles.members}>
        <MemberDetailPage />
      </ProtectedRoute>
    ),
  },
  {
    path: '/profile',
    element: (
      <ProtectedRoute roles={null}>
        <ProfilePage />
      </ProtectedRoute>
    ),
  },
]
