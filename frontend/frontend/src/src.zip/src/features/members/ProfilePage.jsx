import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useMutation } from '@tanstack/react-query'
import { useAuth } from '../../lib/auth'
import api from '../../lib/api'
import { getApiErrorMessage } from '../../lib/apiError'
import { useToast } from '../../components/ui/Toast'
import { Button } from '../../components/ui/Button'
import { Input } from '../../components/ui/Input'
import { Badge } from '../../components/ui/Badge'

const schema = z.object({
  name: z.string().min(1, 'Name is required').max(120),
  phone: z.string().max(40).optional().or(z.literal('')),
  address: z.string().max(255).optional().or(z.literal('')),
})

function FormField({ label, error, children }) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 dark:text-slate-200">{label}</label>
      <div className="mt-1">{children}</div>
      {error ? <p className="mt-1 text-xs text-red-600">{error}</p> : null}
    </div>
  )
}

function roleTone(role) {
  if (role === 'admin') return 'indigo'
  if (role === 'librarian') return 'blue'
  return 'gray'
}

export default function ProfilePage() {
  const { user, refreshMe } = useAuth()
  const { toast } = useToast()

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting, isDirty },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: { name: '', phone: '', address: '' },
  })

  useEffect(() => {
    if (user) {
      reset({
        name: user.name ?? '',
        phone: user.phone ?? '',
        address: user.address ?? '',
      })
    }
  }, [user, reset])

  const update = useMutation({
    mutationFn: (data) => api.patch(`/users/${user.id}`, data),
    onSuccess: async () => {
      await refreshMe()
      toast({ tone: 'success', title: 'Profile updated.' })
    },
    onError: (err) => toast({ tone: 'error', title: 'Error', description: getApiErrorMessage(err) }),
  })

  function onSubmit(values) {
    const payload = { name: values.name }
    if (values.phone !== undefined) payload.phone = values.phone || null
    if (values.address !== undefined) payload.address = values.address || null
    update.mutate(payload)
  }

  if (!user) return null

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-slate-100">My Profile</h1>
        <p className="mt-1 text-sm text-gray-500 dark:text-slate-400">Update your personal information.</p>
      </div>

      <div className="max-w-lg rounded-lg bg-white dark:bg-slate-900 shadow ring-1 ring-gray-200 dark:ring-slate-800 p-6 space-y-6">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-full bg-indigo-100 flex items-center justify-center">
            <span className="text-lg font-semibold text-indigo-700">
              {user.name?.[0]?.toUpperCase() ?? '?'}
            </span>
          </div>
          <div>
            <p className="text-sm text-gray-500 dark:text-slate-400">{user.email}</p>
            <div className="flex gap-2 mt-1">
              <Badge tone={roleTone(user.role)}>{user.role}</Badge>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <FormField label="Full name" error={errors.name?.message}>
            <Input invalid={Boolean(errors.name)} {...register('name')} />
          </FormField>

          <FormField label="Phone" error={errors.phone?.message}>
            <Input invalid={Boolean(errors.phone)} {...register('phone')} placeholder="Optional" />
          </FormField>

          <FormField label="Address" error={errors.address?.message}>
            <Input invalid={Boolean(errors.address)} {...register('address')} placeholder="Optional" />
          </FormField>

          <div className="flex justify-end pt-2">
            <Button type="submit" disabled={isSubmitting || update.isPending || !isDirty}>
              {update.isPending ? 'Saving…' : 'Save changes'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
