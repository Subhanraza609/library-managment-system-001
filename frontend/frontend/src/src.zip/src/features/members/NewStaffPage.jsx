import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useNavigate, Link } from 'react-router-dom'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import api from '../../lib/api'
import { getApiErrorMessage } from '../../lib/apiError'
import { useToast } from '../../components/ui/Toast'
import { Button } from '../../components/ui/Button'
import { Input } from '../../components/ui/Input'
import { Select } from '../../components/ui/Select'

const schema = z.object({
  name: z.string().min(1, 'Name is required').max(120),
  email: z.string().min(1, 'Email is required').email('Enter a valid email'),
  password: z.string().min(6, 'Password must be at least 6 characters').max(128),
  role: z.enum(['librarian', 'admin'], { required_error: 'Role is required' }),
  phone: z.string().max(40).optional().or(z.literal('')),
  address: z.string().max(255).optional().or(z.literal('')),
})

function FormField({ label, error, children }) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 dark:text-slate-200">{label}</label>
      <div className="mt-1">{children}</div>
      {error ? <p className="mt-1 text-xs text-red-600">{error}</p> : null}
    </div>
  )
}

export default function NewStaffPage() {
  const { toast } = useToast()
  const navigate = useNavigate()
  const queryClient = useQueryClient()

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({ resolver: zodResolver(schema) })

  const create = useMutation({
    mutationFn: (data) => api.post('/users', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] })
      toast({ tone: 'success', title: 'Staff account created.' })
      navigate('/members')
    },
    onError: (err) => toast({ tone: 'error', title: 'Error', description: getApiErrorMessage(err) }),
  })

  function onSubmit(values) {
    const payload = { ...values }
    if (!payload.phone) delete payload.phone
    if (!payload.address) delete payload.address
    create.mutate(payload)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-slate-100">Add Staff Member</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-slate-400">Create a librarian or admin account.</p>
        </div>
        <Link
          to="/members"
          className="text-sm font-medium text-indigo-600 hover:text-indigo-500"
        >
          ← Back to members
        </Link>
      </div>

      <div className="max-w-lg rounded-lg bg-white dark:bg-slate-900 shadow ring-1 ring-gray-200 dark:ring-slate-800 p-6">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <FormField label="Full name" error={errors.name?.message}>
            <Input invalid={Boolean(errors.name)} {...register('name')} />
          </FormField>

          <FormField label="Email" error={errors.email?.message}>
            <Input type="email" invalid={Boolean(errors.email)} {...register('email')} />
          </FormField>

          <FormField label="Password" error={errors.password?.message}>
            <Input type="password" invalid={Boolean(errors.password)} {...register('password')} />
          </FormField>

          <FormField label="Role" error={errors.role?.message}>
            <Select invalid={Boolean(errors.role)} {...register('role')}>
              <option value="">Select role…</option>
              <option value="librarian">Librarian</option>
              <option value="admin">Admin</option>
            </Select>
          </FormField>

          <FormField label="Phone (optional)" error={errors.phone?.message}>
            <Input invalid={Boolean(errors.phone)} {...register('phone')} />
          </FormField>

          <FormField label="Address (optional)" error={errors.address?.message}>
            <Input invalid={Boolean(errors.address)} {...register('address')} />
          </FormField>

          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="secondary" onClick={() => navigate('/members')}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting || create.isPending}>
              {create.isPending ? 'Creating…' : 'Create account'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
