import { useParams, Link } from 'react-router-dom'
import { Skeleton } from '../../components/ui/index'
import { BookForm } from './BookForm'
import { useBook } from './hooks'

export default function BookEditPage() {
  const { id } = useParams()
  const { data: book, isLoading } = useBook(id)

  if (isLoading) {
    return (
      <div className="space-y-4 max-w-lg">
        <Skeleton className="h-7 w-1/3" />
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-10 w-full" />
        ))}
      </div>
    )
  }

  if (!book) return null

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold text-gray-900 dark:text-slate-100">Edit Book</h1>
        <Link
          to={`/catalog/${id}`}
          className="text-sm font-medium text-indigo-600 hover:text-indigo-500"
        >
          ← Back to book
        </Link>
      </div>
      <BookForm book={book} />
    </div>
  )
}
