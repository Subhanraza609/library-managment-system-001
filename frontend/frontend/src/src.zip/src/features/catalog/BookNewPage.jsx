import { Link } from 'react-router-dom'
import { BookForm } from './BookForm'

export default function BookNewPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold text-gray-900 dark:text-slate-100">Add Book</h1>
        <Link
          to="/catalog"
          className="text-sm font-medium text-indigo-600 hover:text-indigo-500"
        >
          ← Back to catalog
        </Link>
      </div>
      <BookForm />
    </div>
  )
}
