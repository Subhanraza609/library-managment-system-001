import { ProtectedRoute } from '../../components/layout/ProtectedRoute'
import CatalogPage from './CatalogPage'
import BookDetailPage from './BookDetailPage'
import BookNewPage from './BookNewPage'
import BookEditPage from './BookEditPage'
import CategoriesPage from './CategoriesPage'

const STAFF = ['admin', 'librarian']

export const routes = [
  { path: '/catalog', element: <CatalogPage /> },
  { path: '/catalog/:id', element: <BookDetailPage /> },
  {
    path: '/catalog/new',
    element: (
      <ProtectedRoute roles={STAFF}>
        <BookNewPage />
      </ProtectedRoute>
    ),
  },
  {
    path: '/catalog/:id/edit',
    element: (
      <ProtectedRoute roles={STAFF}>
        <BookEditPage />
      </ProtectedRoute>
    ),
  },
  {
    path: '/catalog/categories',
    element: (
      <ProtectedRoute roles={STAFF}>
        <CategoriesPage />
      </ProtectedRoute>
    ),
  },
]
