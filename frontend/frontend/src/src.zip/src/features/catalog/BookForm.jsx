import { useState } from 'react'
import { Controller, useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useNavigate } from 'react-router-dom'
import { getApiErrorMessage } from '../../lib/apiError'
import {
  Button,
  FileUpload,
  Input,
  Select,
  Textarea,
  useToast,
} from '../../components/ui/index'
import { FormField } from '../auth/FormField'
import { assetUrl } from '../../lib/api'
import { useCategories, useCreateBook, useUpdateBook, useUploadCover } from './hooks'

const schema = z
  .object({
    title: z.string().min(1, 'Title is required').max(255),
    author: z.string().min(1, 'Author is required').max(255),
    isbn: z.string().max(20).optional().or(z.literal('')),
    category_id: z.string().optional(),
    description: z.string().optional(),
    total_copies: z.coerce.number().int().min(1, 'Must be at least 1'),
    available_copies: z.preprocess(
      (v) => (v === '' || v == null ? undefined : v),
      z.coerce.number().int().min(0, 'Cannot be negative').optional(),
    ),
    publisher: z.string().max(255).optional().or(z.literal('')),
    publication_year: z.preprocess(
      (v) => (v === '' || v == null ? undefined : v),
      z.coerce.number().int().min(0).max(9999).optional(),
    ),
  })
  .refine(
    (d) =>
      d.available_copies === undefined ||
      d.available_copies === '' ||
      Number(d.available_copies) <= Number(d.total_copies),
    { message: 'Available copies cannot exceed total copies', path: ['available_copies'] },
  )

function toApiPayload(values) {
  return {
    title: values.title,
    author: values.author,
    isbn: values.isbn || undefined,
    category_id: values.category_id ? Number(values.category_id) : undefined,
    description: values.description || undefined,
    total_copies: Number(values.total_copies),
    available_copies: values.available_copies !== '' && values.available_copies !== undefined
      ? Number(values.available_copies)
      : undefined,
    publisher: values.publisher || undefined,
    publication_year: values.publication_year !== '' && values.publication_year !== undefined
      ? Number(values.publication_year)
      : undefined,
  }
}

export function BookForm({ book }) {
  const isEditing = Boolean(book)
  const navigate = useNavigate()
  const { toast } = useToast()
  const [coverFile, setCoverFile] = useState(null)
  const [coverPreview, setCoverPreview] = useState(book?.cover_image_url ?? null)

  const { data: catData } = useCategories()
  const categories = catData?.items ?? []

  const createMutation = useCreateBook()
  const updateMutation = useUpdateBook(book?.id)
  const coverMutation = useUploadCover(book?.id)

  const {
    register,
    handleSubmit,
    control,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: {
      title: book?.title ?? '',
      author: book?.author ?? '',
      isbn: book?.isbn ?? '',
      category_id: book?.category?.id ? String(book.category.id) : '',
      description: book?.description ?? '',
      total_copies: book?.total_copies ?? 1,
      available_copies: book?.available_copies ?? '',
      publisher: book?.publisher ?? '',
      publication_year: book?.publication_year ?? '',
    },
  })

  function handleFileSelect(file) {
    setCoverFile(file)
    if (file) {
      setCoverPreview(URL.createObjectURL(file))
    }
  }

  async function onSubmit(values) {
    try {
      const payload = toApiPayload(values)
      let saved
      if (isEditing) {
        saved = await updateMutation.mutateAsync(payload)
      } else {
        saved = await createMutation.mutateAsync(payload)
      }
      if (coverFile) {
        await coverMutation.mutateAsync(coverFile)
      }
      toast({ tone: 'success', title: isEditing ? 'Book updated' : 'Book created' })
      navigate(`/catalog/${saved.id}`)
    } catch (err) {
      toast({ tone: 'error', title: 'Save failed', description: getApiErrorMessage(err) })
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-5 max-w-lg">
      <FormField label="Title *" error={errors.title?.message}>
        {({ id, invalid }) => (
          <Input id={id} invalid={invalid} {...register('title')} />
        )}
      </FormField>

      <FormField label="Author *" error={errors.author?.message}>
        {({ id, invalid }) => (
          <Input id={id} invalid={invalid} {...register('author')} />
        )}
      </FormField>

      <FormField label="ISBN" error={errors.isbn?.message}>
        {({ id, invalid }) => (
          <Input id={id} invalid={invalid} {...register('isbn')} />
        )}
      </FormField>

      <FormField label="Category" error={errors.category_id?.message}>
        {({ id, invalid }) => (
          <Controller
            name="category_id"
            control={control}
            render={({ field }) => (
              <Select id={id} invalid={invalid} {...field}>
                <option value="">No category</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </Select>
            )}
          />
        )}
      </FormField>

      <FormField label="Description" error={errors.description?.message}>
        {({ id, invalid }) => (
          <Textarea id={id} invalid={invalid} rows={3} {...register('description')} />
        )}
      </FormField>

      <div className="grid grid-cols-2 gap-4">
        <FormField label="Total copies *" error={errors.total_copies?.message}>
          {({ id, invalid }) => (
            <Input id={id} type="number" min={1} invalid={invalid} {...register('total_copies')} />
          )}
        </FormField>

        <FormField label="Available copies" error={errors.available_copies?.message}>
          {({ id, invalid }) => (
            <Input id={id} type="number" min={0} invalid={invalid} {...register('available_copies')} />
          )}
        </FormField>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <FormField label="Publisher" error={errors.publisher?.message}>
          {({ id, invalid }) => (
            <Input id={id} invalid={invalid} {...register('publisher')} />
          )}
        </FormField>

        <FormField label="Publication year" error={errors.publication_year?.message}>
          {({ id, invalid }) => (
            <Input id={id} type="number" min={0} max={9999} invalid={invalid} {...register('publication_year')} />
          )}
        </FormField>
      </div>

      <div>
        <p className="mb-1 text-sm font-medium text-gray-700 dark:text-slate-200">Cover image</p>
        {coverPreview && (
          <img
            src={assetUrl(coverPreview)}
            alt="Cover preview"
            className="mb-2 h-32 w-24 rounded object-cover"
          />
        )}
        <FileUpload
          accept="image/*"
          label="Choose cover"
          onSelect={handleFileSelect}
        />
      </div>

      <div className="flex gap-2 pt-2">
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? 'Saving…' : isEditing ? 'Save changes' : 'Create book'}
        </Button>
        <Button type="button" variant="secondary" onClick={() => navigate(-1)}>
          Cancel
        </Button>
      </div>
    </form>
  )
}
