import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { useAuth } from '../../lib/auth'
import { getApiErrorMessage } from '../../lib/apiError'
import {
  Button,
  Modal,
  Skeleton,
  useToast,
} from '../../components/ui/index'
import { AvailabilityBadge } from './AvailabilityBadge'
import { useBook, useDeleteBook } from './hooks'
import { useBorrowBook, useCreateReservation } from '../loans/useLoans'
import { assetUrl } from '../../lib/api'

export default function BookDetailPage() {
  const { id } = useParams()
  const { role } = useAuth()
  const isStaff = role === 'admin' || role === 'librarian'
  const navigate = useNavigate()
  const { toast } = useToast()
  const [deleteOpen, setDeleteOpen] = useState(false)

  const { data: book, isLoading } = useBook(id)
  const deleteMutation = useDeleteBook()
  const isMember = role === 'member'
  const borrowMutation = useBorrowBook()
  const reserveMutation = useCreateReservation()

  async function handleDelete() {
    try {
      await deleteMutation.mutateAsync(id)
      toast({ tone: 'success', title: 'Book deleted' })
      navigate('/catalog')
    } catch (err) {
      toast({ tone: 'error', title: 'Delete failed', description: getApiErrorMessage(err) })
    }
    setDeleteOpen(false)
  }

  async function handleBorrow() {
    try {
      await borrowMutation.mutateAsync({ book_id: Number(book.id) })
      toast({ tone: 'success', title: 'Borrowed', description: `"${book.title}" is due in 14 days.` })
      navigate('/loans')
    } catch (err) {
      toast({ tone: 'error', title: 'Could not borrow', description: getApiErrorMessage(err) })
    }
  }

  async function handleReserve() {
    try {
      await reserveMutation.mutateAsync({ book_id: Number(book.id) })
      toast({ tone: 'success', title: 'Reserved', description: `We'll notify you when "${book.title}" is available.` })
    } catch (err) {
      toast({ tone: 'error', title: 'Could not reserve', description: getApiErrorMessage(err) })
    }
  }

  if (isLoading) {
    return (
      <div className="flex gap-8">
        <Skeleton className="h-72 w-48 shrink-0 rounded-xl" />
        <div className="flex-1 space-y-3">
          <Skeleton className="h-7 w-2/3" />
          <Skeleton className="h-5 w-1/3" />
          <Skeleton className="h-4 w-1/4" />
        </div>
      </div>
    )
  }

  if (!book) return null

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Link to="/catalog" className="text-sm text-indigo-600 hover:underline">
          Catalog
        </Link>
        <span className="text-gray-400 dark:text-slate-500">/</span>
        <span className="text-sm text-gray-600 dark:text-slate-300">{book.title}</span>
      </div>

      <div className="flex flex-col gap-8 sm:flex-row">
        <div className="shrink-0">
          {book.cover_image_url ? (
            <img
              src={assetUrl(book.cover_image_url)}
              alt={book.title}
              className="h-72 w-48 rounded-xl object-cover shadow"
            />
          ) : (
            <div className="flex h-72 w-48 items-center justify-center rounded-xl bg-gray-100 dark:bg-slate-800 text-gray-300 shadow">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-16 w-16"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={1}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
                />
              </svg>
            </div>
          )}
        </div>

        <div className="flex-1 space-y-4">
          <div className="space-y-1">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-slate-100">{book.title}</h1>
            <p className="text-base text-gray-600 dark:text-slate-300">{book.author}</p>
            {book.isbn && (
              <p className="text-sm text-gray-400 dark:text-slate-500">ISBN: {book.isbn}</p>
            )}
          </div>

          <AvailabilityBadge availability={book.availability} />

          <dl className="grid grid-cols-2 gap-x-6 gap-y-3 text-sm">
            {book.category && (
              <>
                <dt className="font-medium text-gray-700 dark:text-slate-200">Category</dt>
                <dd className="text-gray-600 dark:text-slate-300">{book.category.name}</dd>
              </>
            )}
            {book.publisher && (
              <>
                <dt className="font-medium text-gray-700 dark:text-slate-200">Publisher</dt>
                <dd className="text-gray-600 dark:text-slate-300">{book.publisher}</dd>
              </>
            )}
            {book.publication_year ? (
              <>
                <dt className="font-medium text-gray-700 dark:text-slate-200">Year</dt>
                <dd className="text-gray-600 dark:text-slate-300">{book.publication_year}</dd>
              </>
            ) : null}
            <dt className="font-medium text-gray-700 dark:text-slate-200">Total copies</dt>
            <dd className="text-gray-600 dark:text-slate-300">{book.total_copies}</dd>
            <dt className="font-medium text-gray-700 dark:text-slate-200">Available</dt>
            <dd className="text-gray-600 dark:text-slate-300">{book.available_copies}</dd>
          </dl>

          {book.description && (
            <p className="text-sm text-gray-600 dark:text-slate-300 leading-relaxed">{book.description}</p>
          )}

          {isMember && (
            <div className="flex gap-2 pt-2">
              {book.available_copies > 0 ? (
                <Button size="sm" onClick={handleBorrow} disabled={borrowMutation.isPending}>
                  {borrowMutation.isPending ? 'Borrowing…' : 'Borrow'}
                </Button>
              ) : (
                <Button variant="secondary" size="sm" onClick={handleReserve} disabled={reserveMutation.isPending}>
                  {reserveMutation.isPending ? 'Reserving…' : 'Reserve'}
                </Button>
              )}
            </div>
          )}

          {isStaff && (
            <div className="flex gap-2 pt-2">
              <Button variant="secondary" size="sm" asChild>
                <Link to={`/catalog/${book.id}/edit`}>Edit</Link>
              </Button>
              <Button
                variant="danger"
                size="sm"
                onClick={() => setDeleteOpen(true)}
              >
                Delete
              </Button>
            </div>
          )}
        </div>
      </div>

      <Modal
        open={deleteOpen}
        onClose={() => setDeleteOpen(false)}
        title="Delete book"
        footer={
          <>
            <Button variant="secondary" onClick={() => setDeleteOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              onClick={handleDelete}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? 'Deleting…' : 'Delete'}
            </Button>
          </>
        }
      >
        <p className="text-sm text-gray-600 dark:text-slate-300">
          Are you sure you want to delete <strong>{book.title}</strong>? This
          cannot be undone.
        </p>
      </Modal>
    </div>
  )
}
