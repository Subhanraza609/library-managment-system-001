import { Link } from 'react-router-dom'
import { assetUrl } from '../../lib/api'
import { AvailabilityBadge } from './AvailabilityBadge'

export function BookCard({ book }) {
  return (
    <Link
      to={`/catalog/${book.id}`}
      className="group flex flex-col overflow-hidden rounded-xl border border-gray-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm transition hover:shadow-md"
    >
      <div className="aspect-[2/3] w-full overflow-hidden bg-gray-100 dark:bg-slate-800">
        {book.cover_image_url ? (
          <img
            src={assetUrl(book.cover_image_url)}
            alt={book.title}
            className="h-full w-full object-cover transition group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-gray-300">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-16 w-16"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={1}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
              />
            </svg>
          </div>
        )}
      </div>
      <div className="flex flex-1 flex-col gap-1 p-3">
        <p className="line-clamp-2 text-sm font-medium text-gray-900 dark:text-slate-100 leading-snug">
          {book.title}
        </p>
        <p className="text-xs text-gray-500 dark:text-slate-400">{book.author}</p>
        <div className="mt-auto pt-2">
          <AvailabilityBadge availability={book.availability} />
        </div>
      </div>
    </Link>
  )
}
