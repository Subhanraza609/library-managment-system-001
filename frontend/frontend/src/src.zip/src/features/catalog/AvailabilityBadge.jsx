import { Badge } from '../../components/ui/index'

const toneMap = {
  available: 'green',
  borrowed: 'red',
  reserved: 'yellow',
}

const labelMap = {
  available: 'Available',
  borrowed: 'Borrowed',
  reserved: 'Reserved',
}

export function AvailabilityBadge({ availability }) {
  const tone = toneMap[availability] ?? 'gray'
  const label = labelMap[availability] ?? availability
  return <Badge tone={tone}>{label}</Badge>
}
