import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import api from '../../lib/api'

const BOOKS_KEY = 'books'
const CATEGORIES_KEY = 'categories'

// ── Books ─────────────────────────────────────────────────────────────────────

export function useBooks(params) {
  return useQuery({
    queryKey: [BOOKS_KEY, params],
    queryFn: () => api.get('/books', { params }).then((r) => r.data),
  })
}

export function useBook(id) {
  return useQuery({
    queryKey: [BOOKS_KEY, id],
    queryFn: () => api.get(`/books/${id}`).then((r) => r.data.book),
    enabled: Boolean(id),
  })
}

export function useCreateBook() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (data) => api.post('/books', data).then((r) => r.data.book),
    onSuccess: () => qc.invalidateQueries({ queryKey: [BOOKS_KEY] }),
  })
}

export function useUpdateBook(id) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (data) => api.patch(`/books/${id}`, data).then((r) => r.data.book),
    onSuccess: () => qc.invalidateQueries({ queryKey: [BOOKS_KEY] }),
  })
}

export function useDeleteBook() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id) => api.delete(`/books/${id}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: [BOOKS_KEY] }),
  })
}

export function useUploadCover(id) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (file) => {
      const fd = new FormData()
      fd.append('file', file)
      return api.post(`/books/${id}/cover`, fd, {
        headers: { 'Content-Type': 'multipart/form-data' },
      }).then((r) => r.data.book)
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: [BOOKS_KEY] }),
  })
}

// ── Categories ────────────────────────────────────────────────────────────────

export function useCategories() {
  return useQuery({
    queryKey: [CATEGORIES_KEY],
    queryFn: () => api.get('/categories').then((r) => r.data),
  })
}

export function useCreateCategory() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (data) => api.post('/categories', data).then((r) => r.data.category),
    onSuccess: () => qc.invalidateQueries({ queryKey: [CATEGORIES_KEY] }),
  })
}

export function useUpdateCategory(id) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (data) => api.patch(`/categories/${id}`, data).then((r) => r.data.category),
    onSuccess: () => qc.invalidateQueries({ queryKey: [CATEGORIES_KEY] }),
  })
}

export function useDeleteCategory() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id) => api.delete(`/categories/${id}`),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: [CATEGORIES_KEY] })
      qc.invalidateQueries({ queryKey: [BOOKS_KEY] })
    },
  })
}
