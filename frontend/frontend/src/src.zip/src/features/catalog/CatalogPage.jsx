import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../../lib/auth'
import {
  Button,
  EmptyState,
  Input,
  Pagination,
  Select,
  Skeleton,
} from '../../components/ui/index'
import { BookCard } from './BookCard'
import { useBooks, useCategories } from './hooks'

const STATUS_OPTIONS = [
  { value: '', label: 'All statuses' },
  { value: 'available', label: 'Available' },
  { value: 'borrowed', label: 'Borrowed' },
  { value: 'reserved', label: 'Reserved' },
]

export default function CatalogPage() {
  const { role } = useAuth()
  const isStaff = role === 'admin' || role === 'librarian'

  const [q, setQ] = useState('')
  const [categoryId, setCategoryId] = useState('')
  const [status, setStatus] = useState('')
  const [page, setPage] = useState(1)

  const params = {
    page,
    page_size: 12,
    ...(q ? { q } : {}),
    ...(categoryId ? { category_id: categoryId } : {}),
    ...(status ? { status } : {}),
  }

  const { data, isLoading } = useBooks(params)
  const { data: catData } = useCategories()

  const books = data?.items ?? []
  const total = data?.total ?? 0
  const pageSize = data?.page_size ?? 12

  const categories = catData?.items ?? []

  function handleSearch(e) {
    e.preventDefault()
    setPage(1)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold text-gray-900 dark:text-slate-100">Book Catalog</h1>
        {isStaff && (
          <div className="flex gap-2">
            <Button variant="secondary" size="sm" asChild>
              <Link to="/catalog/categories">Manage Categories</Link>
            </Button>
            <Button size="sm" asChild>
              <Link to="/catalog/new">Add Book</Link>
            </Button>
          </div>
        )}
      </div>

      {/* Filters */}
      <form onSubmit={handleSearch} className="flex flex-wrap gap-3">
        <Input
          placeholder="Search title, author, or ISBN…"
          value={q}
          onChange={(e) => { setQ(e.target.value); setPage(1) }}
          className="max-w-xs"
        />
        <Select
          value={categoryId}
          onChange={(e) => { setCategoryId(e.target.value); setPage(1) }}
          className="max-w-[180px]"
        >
          <option value="">All categories</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </Select>
        <Select
          value={status}
          onChange={(e) => { setStatus(e.target.value); setPage(1) }}
          className="max-w-[160px]"
        >
          {STATUS_OPTIONS.map((o) => (
            <option key={o.value} value={o.value}>{o.label}</option>
          ))}
        </Select>
      </form>

      {/* Grid */}
      {isLoading ? (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
          {Array.from({ length: 12 }).map((_, i) => (
            <Skeleton key={i} className="aspect-[2/3] w-full rounded-xl" />
          ))}
        </div>
      ) : books.length === 0 ? (
        <EmptyState
          title="No books found"
          description="Try adjusting your search or filters."
          action={
            isStaff ? (
              <Button size="sm" asChild>
                <Link to="/catalog/new">Add a book</Link>
              </Button>
            ) : null
          }
        />
      ) : (
        <>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
            {books.map((book) => (
              <BookCard key={book.id} book={book} />
            ))}
          </div>
          <Pagination
            page={page}
            pageSize={pageSize}
            total={total}
            onPageChange={setPage}
          />
        </>
      )}
    </div>
  )
}
