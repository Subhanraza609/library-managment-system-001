import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { getApiErrorMessage } from '../../lib/apiError'
import {
  Button,
  EmptyState,
  Input,
  Modal,
  Skeleton,
  Table,
  TBody,
  TD,
  TH,
  THead,
  TR,
  Textarea,
  useToast,
} from '../../components/ui/index'
import { FormField } from '../auth/FormField'
import {
  useCategories,
  useCreateCategory,
  useDeleteCategory,
  useUpdateCategory,
} from './hooks'

const schema = z.object({
  name: z.string().min(1, 'Name is required').max(80),
  description: z.string().max(255).optional(),
})

function CategoryModal({ open, onClose, category }) {
  const isEditing = Boolean(category)
  const { toast } = useToast()
  const createMutation = useCreateCategory()
  const updateMutation = useUpdateCategory(category?.id)

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: {
      name: category?.name ?? '',
      description: category?.description ?? '',
    },
  })

  useState(() => {
    if (open) {
      reset({ name: category?.name ?? '', description: category?.description ?? '' })
    }
  }, [open])

  async function onSubmit(values) {
    try {
      if (isEditing) {
        await updateMutation.mutateAsync(values)
        toast({ tone: 'success', title: 'Category updated' })
      } else {
        await createMutation.mutateAsync(values)
        toast({ tone: 'success', title: 'Category created' })
      }
      reset()
      onClose()
    } catch (err) {
      toast({ tone: 'error', title: 'Save failed', description: getApiErrorMessage(err) })
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={isEditing ? 'Edit Category' : 'New Category'}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button type="submit" form="cat-form" disabled={isSubmitting}>
            {isSubmitting ? 'Saving…' : isEditing ? 'Save changes' : 'Create'}
          </Button>
        </>
      }
    >
      <form id="cat-form" onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <FormField label="Name *" error={errors.name?.message}>
          {({ id, invalid }) => (
            <Input id={id} invalid={invalid} {...register('name')} />
          )}
        </FormField>
        <FormField label="Description" error={errors.description?.message}>
          {({ id, invalid }) => (
            <Textarea id={id} invalid={invalid} rows={2} {...register('description')} />
          )}
        </FormField>
      </form>
    </Modal>
  )
}

export default function CategoriesPage() {
  const { toast } = useToast()
  const [modalOpen, setModalOpen] = useState(false)
  const [editTarget, setEditTarget] = useState(null)
  const [deleteTarget, setDeleteTarget] = useState(null)

  const { data, isLoading } = useCategories()
  const deleteMutation = useDeleteCategory()

  const categories = data?.items ?? []

  function openCreate() {
    setEditTarget(null)
    setModalOpen(true)
  }

  function openEdit(cat) {
    setEditTarget(cat)
    setModalOpen(true)
  }

  async function confirmDelete() {
    try {
      await deleteMutation.mutateAsync(deleteTarget.id)
      toast({ tone: 'success', title: 'Category deleted' })
    } catch (err) {
      toast({ tone: 'error', title: 'Delete failed', description: getApiErrorMessage(err) })
    }
    setDeleteTarget(null)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h1 className="text-xl font-semibold text-gray-900 dark:text-slate-100">Categories</h1>
          <Link
            to="/catalog"
            className="text-sm font-medium text-indigo-600 hover:text-indigo-500"
          >
            ← Back to catalog
          </Link>
        </div>
        <Button size="sm" onClick={openCreate}>New Category</Button>
      </div>

      {isLoading ? (
        <div className="space-y-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-10 w-full" />
          ))}
        </div>
      ) : categories.length === 0 ? (
        <EmptyState
          title="No categories yet"
          action={<Button size="sm" onClick={openCreate}>Create one</Button>}
        />
      ) : (
        <Table>
          <THead>
            <TR>
              <TH>Name</TH>
              <TH>Description</TH>
              <TH>Created</TH>
              <TH />
            </TR>
          </THead>
          <TBody>
            {categories.map((cat) => (
              <TR key={cat.id}>
                <TD className="font-medium">{cat.name}</TD>
                <TD className="text-gray-500 dark:text-slate-400">{cat.description ?? '—'}</TD>
                <TD className="text-gray-500 dark:text-slate-400">
                  {cat.created_at ? new Date(cat.created_at).toLocaleDateString() : '—'}
                </TD>
                <TD>
                  <div className="flex justify-end gap-2">
                    <Button variant="ghost" size="sm" onClick={() => openEdit(cat)}>
                      Edit
                    </Button>
                    <Button
                      variant="danger"
                      size="sm"
                      onClick={() => setDeleteTarget(cat)}
                    >
                      Delete
                    </Button>
                  </div>
                </TD>
              </TR>
            ))}
          </TBody>
        </Table>
      )}

      <CategoryModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        category={editTarget}
      />

      <Modal
        open={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        title="Delete category"
        footer={
          <>
            <Button variant="secondary" onClick={() => setDeleteTarget(null)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              onClick={confirmDelete}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? 'Deleting…' : 'Delete'}
            </Button>
          </>
        }
      >
        <p className="text-sm text-gray-600 dark:text-slate-300">
          Delete <strong>{deleteTarget?.name}</strong>? Books in this category will
          become uncategorized.
        </p>
      </Modal>
    </div>
  )
}
