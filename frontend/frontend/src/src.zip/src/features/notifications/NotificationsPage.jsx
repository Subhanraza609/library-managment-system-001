import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import api from '../../lib/api'
import { getApiErrorMessage } from '../../lib/apiError'
import { useToast } from '../../components/ui/Toast'
import { Button } from '../../components/ui/Button'
import { Badge } from '../../components/ui/Badge'
import { Table, THead, TBody, TR, TH, TD } from '../../components/ui/Table'
import { EmptyState } from '../../components/ui/EmptyState'
import { Skeleton } from '../../components/ui/Skeleton'

export default function NotificationsPage() {
  const { toast } = useToast()
  const queryClient = useQueryClient()

  const { data, isLoading } = useQuery({
    queryKey: ['notifications'],
    queryFn: () => api.get('/notifications', { params: { page_size: 100 } }).then((r) => r.data),
  })

  const run = useMutation({
    mutationFn: () => api.post('/notifications/run').then((r) => r.data),
    onSuccess: (counts) => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] })
      toast({
        tone: 'success',
        title: 'Reminders processed',
        description: `Due soon: ${counts.due_soon ?? 0} · Overdue: ${counts.overdue ?? 0} · Failed: ${counts.failed ?? 0} · Skipped: ${counts.skipped ?? 0}`,
      })
    },
    onError: (err) => toast({ tone: 'error', title: 'Error', description: getApiErrorMessage(err) }),
  })

  const items = data?.items ?? []

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-slate-100">Reminder Log</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-slate-400">
            Due-soon and overdue email reminders sent to members.
          </p>
        </div>
        <Button onClick={() => run.mutate()} disabled={run.isPending}>
          {run.isPending ? 'Running…' : 'Run reminders now'}
        </Button>
      </div>

      {isLoading ? (
        <div className="space-y-2">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </div>
      ) : items.length === 0 ? (
        <EmptyState
          title="No reminders yet"
          description="Run the reminder job to notify members about due and overdue books."
        />
      ) : (
        <Table>
          <THead>
            <TR>
              <TH>Member</TH>
              <TH>Type</TH>
              <TH>Status</TH>
              <TH>Loan</TH>
              <TH>Sent</TH>
            </TR>
          </THead>
          <TBody>
            {items.map((n) => (
              <TR key={n.id}>
                <TD className="font-medium">{n.member_email ?? '—'}</TD>
                <TD>
                  <Badge tone={n.type === 'overdue' ? 'red' : 'yellow'}>{n.type}</Badge>
                </TD>
                <TD>
                  <Badge tone={n.status === 'sent' ? 'green' : 'red'}>{n.status}</Badge>
                </TD>
                <TD>{n.loan_id ?? '—'}</TD>
                <TD>{n.sent_at ? new Date(n.sent_at).toLocaleString() : '—'}</TD>
              </TR>
            ))}
          </TBody>
        </Table>
      )}
    </div>
  )
}
