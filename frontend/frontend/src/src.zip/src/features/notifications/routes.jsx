import { ProtectedRoute } from '../../components/layout/ProtectedRoute'
import { routeRoles } from '../../components/layout/navConfig'
import NotificationsPage from './NotificationsPage'

export const routes = [
  {
    path: '/notifications',
    element: (
      <ProtectedRoute roles={routeRoles.notifications}>
        <NotificationsPage />
      </ProtectedRoute>
    ),
  },
]
