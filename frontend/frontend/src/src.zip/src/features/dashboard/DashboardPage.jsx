import { Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import api from '../../lib/api'
import { useAuth } from '../../lib/auth'
import { cn } from '../../lib/cn'
import { visibleNavItems } from '../../components/layout/navConfig'

const roleBlurb = {
  admin: 'Manage members, staff, the catalog, loans, fines, and reports.',
  librarian: 'Manage the catalog, process loans and returns, and view reports.',
  member: 'Browse the catalog, borrow books, and track your loans and fines.',
}

const ICONS = {
  book: 'M12 6.042A8.967 8.967 0 0 0 6 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 0 1 6 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 0 1 6-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0 0 18 18a8.967 8.967 0 0 0-6 2.292m0-14.25v14.25',
  loans: 'M7.5 21 3 16.5m0 0L7.5 12M3 16.5h13.5m0-13.5L21 7.5m0 0L16.5 12M21 7.5H7.5',
  clock: 'M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z',
  fines: 'M2.25 8.25h19.5M2.25 9h19.5m-16.5 5.25h6m-6 2.25h3m-3.75 3h15a2.25 2.25 0 0 0 2.25-2.25V6.75A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25v10.5A2.25 2.25 0 0 0 4.5 19.5Z',
  users:
    'M15 19.128a9.38 9.38 0 0 0 2.625.372 9.337 9.337 0 0 0 4.121-.952 4.125 4.125 0 0 0-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 0 1 8.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0 1 11.964-3.07M12 6.375a3.375 3.375 0 1 1-6.75 0 3.375 3.375 0 0 1 6.75 0Zm8.25 2.25a2.625 2.625 0 1 1-5.25 0 2.625 2.625 0 0 1 5.25 0Z',
}

const toneStyles = {
  brand: 'bg-brand-50 text-brand-600 dark:bg-brand-500/15 dark:text-brand-300',
  emerald: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-300',
  amber: 'bg-amber-50 text-amber-600 dark:bg-amber-500/15 dark:text-amber-300',
  red: 'bg-red-50 text-red-600 dark:bg-red-500/15 dark:text-red-300',
}

const borderTones = {
  brand: 'border-t-brand-500',
  emerald: 'border-t-emerald-500',
  amber: 'border-t-amber-500',
  red: 'border-t-red-500',
}

function StatCard({ label, value, tone, icon, query }) {
  const display = query.isLoading ? '…' : query.isError ? '—' : value
  return (
    <div className={cn(
      "rounded-xl border border-slate-200/80 bg-white p-5 shadow-card transition-all duration-300 hover:shadow-card-hover hover:-translate-y-1 dark:border-slate-800/80 dark:bg-slate-900 border-t-[3px]",
      borderTones[tone]
    )}>
      <div className="flex items-center justify-between">
        <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">{label}</p>
        <span className={cn('flex h-8 w-8 items-center justify-center rounded-lg shadow-sm', toneStyles[tone])}>
          <svg
            className="h-4.5 w-4.5"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth={2}
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
          >
            <path d={icon} />
          </svg>
        </span>
      </div>
      <p className="mt-3.5 text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
        {display}
      </p>
    </div>
  )
}

function useStat(key, url, params, enabled = true) {
  return useQuery({
    queryKey: ['stats', key, params],
    queryFn: () => api.get(url, { params: { ...params, page_size: 1 } }).then((r) => r.data),
    enabled,
    staleTime: 30_000,
  })
}

export default function DashboardPage() {
  const { user, role } = useAuth()
  const isStaff = role === 'admin' || role === 'librarian'

  const booksQ = useStat('books', '/books', {})
  const activeQ = useStat('active', '/loans', { status: 'active' })
  const overdueQ = useStat('overdue', '/loans', { overdue: true })
  const finesQ = useStat('fines', '/fines', {})
  const membersQ = useStat('members', '/users', { role: 'member' }, role === 'admin')

  const stats = [
    { label: 'Books in catalog', tone: 'brand', icon: ICONS.book, query: booksQ, value: booksQ.data?.total ?? 0 },
    {
      label: isStaff ? 'Active loans' : 'My active loans',
      tone: 'emerald',
      icon: ICONS.loans,
      query: activeQ,
      value: activeQ.data?.total ?? 0,
    },
    {
      label: isStaff ? 'Overdue loans' : 'My overdue',
      tone: 'red',
      icon: ICONS.clock,
      query: overdueQ,
      value: overdueQ.data?.total ?? 0,
    },
    {
      label: isStaff ? 'Outstanding fines' : 'My fines',
      tone: 'amber',
      icon: ICONS.fines,
      query: finesQ,
      value: `¥${Number(finesQ.data?.total_outstanding ?? 0).toFixed(2)}`,
    },
  ]
  if (role === 'admin') {
    stats.push({
      label: 'Members',
      tone: 'brand',
      icon: ICONS.users,
      query: membersQ,
      value: membersQ.data?.total ?? 0,
    })
  }

  const links = visibleNavItems(role).filter((item) => item.to !== '/dashboard')

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-semibold">
          Welcome{user?.name ? `, ${user.name}` : ''}
        </h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          {roleBlurb[role] ?? 'Welcome to the Library Management System.'}
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((s) => (
          <StatCard key={s.label} {...s} />
        ))}
      </div>

      <div>
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
          Quick links
        </h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {links.map((card) => (
            <Link
              key={card.to}
              to={card.to}
              className="group rounded-xl border border-slate-200 bg-white p-5 shadow-card transition-all hover:-translate-y-0.5 hover:shadow-card-hover dark:border-slate-800 dark:bg-slate-900"
            >
              <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                {card.label}
              </h3>
              <p className="mt-1 flex items-center gap-1 text-sm text-slate-500 dark:text-slate-400">
                Open
                <span className="transition-transform group-hover:translate-x-0.5">→</span>
              </p>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
