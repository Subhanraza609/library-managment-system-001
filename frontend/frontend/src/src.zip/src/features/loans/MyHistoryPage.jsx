import { useState } from 'react'
import { useAuth } from '../../lib/auth'
import {
  EmptyState,
  Pagination,
  Skeleton,
  Table,
  TBody,
  TD,
  TH,
  THead,
  TR,
} from '../../components/ui'
import { useMemberHistory } from './useLoans'
import { LoanStatusBadge } from './LoanStatusBadge'

function fmt(iso) {
  if (!iso) return '—'
  return new Date(iso).toLocaleDateString(undefined, { dateStyle: 'medium' })
}

export default function MyHistoryPage() {
  const { user } = useAuth()
  const [page, setPage] = useState(1)
  const { data, isLoading } = useMemberHistory(user?.id)

  if (isLoading) {
    return (
      <div className="space-y-2 p-6">
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-10 w-full" />
        ))}
      </div>
    )
  }

  const items = data?.items ?? []
  const total = data?.total ?? 0

  return (
    <div className="space-y-4 p-6">
      <h1 className="text-xl font-semibold text-gray-900 dark:text-slate-100">My Loan History</h1>
      {items.length === 0 ? (
        <EmptyState title="No loan history" description="You have not borrowed any books yet." />
      ) : (
        <>
          <Table>
            <THead>
              <TR>
                <TH>Book</TH>
                <TH>Author</TH>
                <TH>Borrowed</TH>
                <TH>Due</TH>
                <TH>Returned</TH>
                <TH>Fine</TH>
                <TH>Status</TH>
              </TR>
            </THead>
            <TBody>
              {items.map((loan) => (
                <TR key={loan.id}>
                  <TD className="font-medium">{loan.book?.title ?? loan.book_id}</TD>
                  <TD>{loan.book?.author ?? '—'}</TD>
                  <TD>{fmt(loan.borrowed_at)}</TD>
                  <TD>{fmt(loan.due_date)}</TD>
                  <TD>{fmt(loan.returned_at)}</TD>
                  <TD>
                    {Number(loan.fine_amount) > 0 ? (
                      <span className="font-medium text-red-600">
                        ${Number(loan.fine_amount).toFixed(2)}
                      </span>
                    ) : (
                      '—'
                    )}
                  </TD>
                  <TD>
                    <LoanStatusBadge status={loan.status} />
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>
          <Pagination
            page={page}
            pageSize={data?.page_size ?? 20}
            total={total}
            onPageChange={setPage}
          />
        </>
      )}
    </div>
  )
}
