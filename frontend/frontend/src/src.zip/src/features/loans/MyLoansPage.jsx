import { useState } from 'react'
import {
  Badge,
  Button,
  EmptyState,
  Pagination,
  Skeleton,
  Table,
  TBody,
  TD,
  TH,
  THead,
  TR,
  useToast,
} from '../../components/ui'
import { useMyLoans, useReturnLoan } from './useLoans'
import { LoanStatusBadge } from './LoanStatusBadge'

function fmt(iso) {
  if (!iso) return '—'
  return new Date(iso).toLocaleDateString(undefined, { dateStyle: 'medium' })
}

export default function MyLoansPage() {
  const [page, setPage] = useState(1)
  const { data, isLoading } = useMyLoans({ page, page_size: 20 })
  const returnLoan = useReturnLoan()
  const { toast } = useToast()

  function handleReturn(loanId) {
    returnLoan.mutate(loanId, {
      onSuccess: () => toast({ title: 'Book returned', tone: 'success' }),
      onError: (err) =>
        toast({
          title: 'Return failed',
          description: err.response?.data?.error?.message ?? 'Unknown error',
          tone: 'error',
        }),
    })
  }

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48" />
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-10 w-full" />
          ))}
        </div>
      </div>
    )
  }

  const items = data?.items ?? []
  const total = data?.total ?? 0

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-slate-100">My Active Loans</h1>
        <p className="mt-1 text-sm text-gray-500 dark:text-slate-400">View and return your currently borrowed books.</p>
      </div>
      {items.length === 0 ? (
        <EmptyState title="No active loans" description="You have no books currently borrowed." />
      ) : (
        <>
          <Table>
            <THead>
              <TR>
                <TH>Book</TH>
                <TH>Author</TH>
                <TH>Borrowed</TH>
                <TH>Due</TH>
                <TH>Status</TH>
                <TH></TH>
              </TR>
            </THead>
            <TBody>
              {items.map((loan) => (
                <TR key={loan.id}>
                  <TD className="font-medium">{loan.book?.title ?? loan.book_id}</TD>
                  <TD>{loan.book?.author ?? '—'}</TD>
                  <TD>{fmt(loan.borrowed_at)}</TD>
                  <TD>
                    <span className={loan.is_overdue ? 'font-semibold text-red-600' : ''}>
                      {fmt(loan.due_date)}
                    </span>
                    {loan.is_overdue && (
                      <Badge tone="red" className="ml-2">
                        Overdue
                      </Badge>
                    )}
                  </TD>
                  <TD>
                    <LoanStatusBadge status={loan.status} />
                  </TD>
                  <TD>
                    <Button
                      size="sm"
                      variant="secondary"
                      disabled={loan.status === 'returned' || returnLoan.isPending}
                      onClick={() => handleReturn(loan.id)}
                    >
                      Return
                    </Button>
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>
          <Pagination
            page={page}
            pageSize={data?.page_size ?? 20}
            total={total}
            onPageChange={setPage}
          />
        </>
      )}
    </div>
  )
}
