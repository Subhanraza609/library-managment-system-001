import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import api from '../../lib/api'
import { Button, Select, Skeleton, useToast } from '../../components/ui'
import { useBorrowBook } from './useLoans'

const schema = z.object({
  member_id: z.coerce
    .number({ invalid_type_error: 'Please select a member' })
    .int()
    .positive('Please select a member'),
  book_id: z.coerce
    .number({ invalid_type_error: 'Please select a book' })
    .int()
    .positive('Please select a book'),
})

export default function CheckoutPage() {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({ resolver: zodResolver(schema) })
  const borrow = useBorrowBook()
  const { toast } = useToast()

  const { data: members, isLoading: loadingMembers } = useQuery({
    queryKey: ['approved-members'],
    queryFn: () =>
      api
        .get('/users', { params: { role: 'member', status: 'approved', page_size: 100 } })
        .then((r) => r.data.items ?? []),
  })

  const { data: books, isLoading: loadingBooks } = useQuery({
    queryKey: ['available-books'],
    queryFn: () =>
      api
        .get('/books', { params: { status: 'available', page_size: 100 } })
        .then((r) => r.data.items ?? []),
  })

  function onSubmit(values) {
    borrow.mutate(values, {
      onSuccess: (data) => {
        toast({
          title: 'Loan created',
          description: `Due: ${new Date(data.loan.due_date).toLocaleDateString(undefined, { dateStyle: 'medium' })}`,
          tone: 'success',
        })
        reset()
      },
      onError: (err) =>
        toast({
          title: 'Checkout failed',
          description: err.response?.data?.error?.message ?? 'Unknown error',
          tone: 'error',
        }),
    })
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-gray-900 dark:text-slate-100">Checkout Desk</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-slate-400">Create a loan for a member.</p>
        </div>
        <Link
          to="/loans"
          className="text-sm font-medium text-indigo-600 hover:text-indigo-500"
        >
          ← Back to loans
        </Link>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="mt-6 max-w-sm space-y-4">
        <div>
          <label className="mb-1 block text-sm font-medium text-gray-700 dark:text-slate-200">
            Member *
          </label>
          {loadingMembers ? (
            <Skeleton className="h-10 w-full rounded-lg" />
          ) : (
            <Select
              invalid={Boolean(errors.member_id)}
              {...register('member_id')}
            >
              <option value="">Select a member…</option>
              {members?.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} ({m.email})
                </option>
              ))}
            </Select>
          )}
          {errors.member_id && (
            <p className="mt-1 text-xs text-red-500">{errors.member_id.message}</p>
          )}
        </div>

        <div>
          <label className="mb-1 block text-sm font-medium text-gray-700 dark:text-slate-200">
            Book *
          </label>
          {loadingBooks ? (
            <Skeleton className="h-10 w-full rounded-lg" />
          ) : (
            <Select
              invalid={Boolean(errors.book_id)}
              {...register('book_id')}
            >
              <option value="">Select a book…</option>
              {books?.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.title} by {b.author} ({b.available_copies} left)
                </option>
              ))}
            </Select>
          )}
          {errors.book_id && (
            <p className="mt-1 text-xs text-red-500">{errors.book_id.message}</p>
          )}
        </div>

        <Button type="submit" disabled={borrow.isPending}>
          {borrow.isPending ? 'Processing…' : 'Check Out'}
        </Button>
      </form>
    </div>
  )
}
