import { useAuth } from '../../lib/auth'
import AllLoansPage from './AllLoansPage'
import MyLoansPage from './MyLoansPage'

export default function LoansPage() {
  const { role } = useAuth()
  if (role === 'admin' || role === 'librarian') {
    return <AllLoansPage />
  }
  return <MyLoansPage />
}
