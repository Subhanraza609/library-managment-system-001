import { Badge } from '../../components/ui'

const toneMap = {
  active: 'green',
  overdue: 'red',
  returned: 'gray',
}

export function LoanStatusBadge({ status }) {
  return <Badge tone={toneMap[status] ?? 'gray'}>{status}</Badge>
}
