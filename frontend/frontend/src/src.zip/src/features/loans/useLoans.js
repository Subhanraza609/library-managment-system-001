import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import api from '../../lib/api'

export function useMyLoans(params = {}) {
  return useQuery({
    queryKey: ['loans', 'mine', params],
    queryFn: async () => {
      const { data } = await api.get('/loans', { params })
      return data
    },
  })
}

export function useAllLoans(params = {}) {
  return useQuery({
    queryKey: ['loans', 'all', params],
    queryFn: async () => {
      const { data } = await api.get('/loans', { params })
      return data
    },
  })
}

export function useMemberHistory(memberId) {
  return useQuery({
    queryKey: ['loans', 'history', memberId],
    queryFn: async () => {
      const { data } = await api.get(`/members/${memberId}/history`)
      return data
    },
    enabled: Boolean(memberId),
  })
}

export function useBorrowBook() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (body) => api.post('/loans', body).then((r) => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['loans'] })
      qc.invalidateQueries({ queryKey: ['books'] })
    },
  })
}

export function useReturnLoan() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (loanId) => api.post(`/loans/${loanId}/return`).then((r) => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['loans'] })
      qc.invalidateQueries({ queryKey: ['books'] })
    },
  })
}

export function useCreateReservation() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (body) => api.post('/reservations', body).then((r) => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['reservations'] })
    },
  })
}

export function useCancelReservation() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (resId) => api.post(`/reservations/${resId}/cancel`).then((r) => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['reservations'] })
    },
  })
}

export function useMyReservations(params = {}) {
  return useQuery({
    queryKey: ['reservations', 'mine', params],
    queryFn: async () => {
      const { data } = await api.get('/reservations', { params })
      return data
    },
  })
}
