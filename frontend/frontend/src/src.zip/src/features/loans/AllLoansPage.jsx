import { useState } from 'react'
import { Link } from 'react-router-dom'
import {
  Badge,
  Button,
  EmptyState,
  Pagination,
  Select,
  Skeleton,
  Table,
  TBody,
  TD,
  TH,
  THead,
  TR,
  useToast,
} from '../../components/ui'
import { useAllLoans, useReturnLoan } from './useLoans'
import { LoanStatusBadge } from './LoanStatusBadge'

function fmt(iso) {
  if (!iso) return '—'
  return new Date(iso).toLocaleDateString(undefined, { dateStyle: 'medium' })
}

export default function AllLoansPage() {
  const [page, setPage] = useState(1)
  const [statusFilter, setStatusFilter] = useState('')
  const [overdueOnly, setOverdueOnly] = useState(false)

  const params = {
    page,
    page_size: 20,
    ...(statusFilter ? { status: statusFilter } : {}),
    ...(overdueOnly ? { overdue: true } : {}),
  }

  const { data, isLoading } = useAllLoans(params)
  const returnLoan = useReturnLoan()
  const { toast } = useToast()

  function handleReturn(loanId) {
    returnLoan.mutate(loanId, {
      onSuccess: () => toast({ title: 'Book returned', tone: 'success' }),
      onError: (err) =>
        toast({
          title: 'Return failed',
          description: err.response?.data?.error?.message ?? 'Unknown error',
          tone: 'error',
        }),
    })
  }

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48" />
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-10 w-full" />
          ))}
        </div>
      </div>
    )
  }

  const items = data?.items ?? []
  const total = data?.total ?? 0

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-slate-100">Book Loans</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-slate-400">
            Manage book checkouts, returns, and track active/overdue loans.
          </p>
        </div>
        <Button as={Link} to="/loans/checkout" size="md">
          Checkout Desk
        </Button>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <Select
          value={statusFilter}
          onChange={(e) => {
            setStatusFilter(e.target.value)
            setPage(1)
          }}
          className="w-36"
        >
          <option value="">All statuses</option>
          <option value="active">Active</option>
          <option value="overdue">Overdue</option>
          <option value="returned">Returned</option>
        </Select>
        <label className="flex items-center gap-1.5 text-sm text-gray-700 dark:text-slate-200">
          <input
            type="checkbox"
            checked={overdueOnly}
            onChange={(e) => {
              setOverdueOnly(e.target.checked)
              setPage(1)
            }}
          />
          Overdue only
        </label>
      </div>

      {items.length === 0 ? (
        <EmptyState title="No loans found" description="Adjust filters or check back later." />
      ) : (
        <>
          <Table>
            <THead>
              <TR>
                <TH>Member</TH>
                <TH>Book</TH>
                <TH>Borrowed</TH>
                <TH>Due</TH>
                <TH>Status</TH>
                <TH>Fine</TH>
                <TH></TH>
              </TR>
            </THead>
            <TBody>
              {items.map((loan) => (
                <TR key={loan.id} className={loan.is_overdue ? 'bg-red-50 hover:bg-red-100' : ''}>
                  <TD>{loan.member?.name ?? loan.member_id}</TD>
                  <TD className="font-medium">{loan.book?.title ?? loan.book_id}</TD>
                  <TD>{fmt(loan.borrowed_at)}</TD>
                  <TD>
                    <span className={loan.is_overdue ? 'font-semibold text-red-600' : ''}>
                      {fmt(loan.due_date)}
                    </span>
                  </TD>
                  <TD>
                    <LoanStatusBadge status={loan.status} />
                    {loan.is_overdue && (
                      <Badge tone="red" className="ml-1">
                        Overdue
                      </Badge>
                    )}
                  </TD>
                  <TD>
                    {Number(loan.fine_amount) > 0
                      ? `$${Number(loan.fine_amount).toFixed(2)}`
                      : '—'}
                  </TD>
                  <TD>
                    {loan.status !== 'returned' && (
                      <Button
                        size="sm"
                        variant="secondary"
                        disabled={returnLoan.isPending}
                        onClick={() => handleReturn(loan.id)}
                      >
                        Return
                      </Button>
                    )}
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>
          <Pagination
            page={page}
            pageSize={data?.page_size ?? 20}
            total={total}
            onPageChange={setPage}
          />
        </>
      )}
    </div>
  )
}
