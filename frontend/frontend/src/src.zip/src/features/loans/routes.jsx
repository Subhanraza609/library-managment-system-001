import { ProtectedRoute } from '../../components/layout/ProtectedRoute'
import LoansPage from './LoansPage'
import MyHistoryPage from './MyHistoryPage'
import CheckoutPage from './CheckoutPage'

export const routes = [
  {
    path: '/loans',
    element: <LoansPage />,
  },
  {
    path: '/loans/history',
    element: <MyHistoryPage />,
  },
  {
    path: '/loans/checkout',
    element: (
      <ProtectedRoute roles={['admin', 'librarian']}>
        <CheckoutPage />
      </ProtectedRoute>
    ),
  },
]
