import { ProtectedRoute } from '../../components/layout/ProtectedRoute'
import { routeRoles } from '../../components/layout/navConfig'
import ReportsPage from './ReportsPage'

export const routes = [
  {
    path: '/reports',
    element: (
      <ProtectedRoute roles={routeRoles.reports}>
        <ReportsPage />
      </ProtectedRoute>
    ),
  },
]
