import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import api from '../../lib/api'
import { useTheme } from '../../lib/theme'
import {
  Badge,
  Button,
  EmptyState,
  Skeleton,
  Table,
  TBody,
  TD,
  TH,
  THead,
  TR,
} from '../../components/ui/index'

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function today() {
  return new Date().toISOString().slice(0, 10)
}

function fmtDate(iso) {
  if (!iso) return '—'
  return new Date(iso).toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  })
}

async function downloadBlob(url, params, filename) {
  const res = await api.get(url, { params, responseType: 'blob' })
  const href = URL.createObjectURL(res.data)
  const a = document.createElement('a')
  a.href = href
  a.download = filename
  a.click()
  URL.revokeObjectURL(href)
}

function ExportButtons({ url, params, baseName }) {
  const [busy, setBusy] = useState(null)

  async function handle(fmt) {
    setBusy(fmt)
    try {
      await downloadBlob(url, { ...params, format: fmt }, `${baseName}.${fmt}`)
    } finally {
      setBusy(null)
    }
  }

  return (
    <div className="flex gap-2">
      <Button
        size="sm"
        variant="secondary"
        disabled={busy === 'csv'}
        onClick={() => handle('csv')}
      >
        {busy === 'csv' ? 'Downloading…' : 'CSV'}
      </Button>
      <Button
        size="sm"
        variant="secondary"
        disabled={busy === 'pdf'}
        onClick={() => handle('pdf')}
      >
        {busy === 'pdf' ? 'Downloading…' : 'PDF'}
      </Button>
    </div>
  )
}

function SectionCard({ title, children }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white shadow-card dark:border-slate-800 dark:bg-slate-900">
      <div className="border-b border-slate-200 px-6 py-4 dark:border-slate-800">
        <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100">{title}</h2>
      </div>
      <div className="p-6">{children}</div>
    </div>
  )
}

function LoadingRows() {
  return (
    <div className="space-y-2">
      {Array.from({ length: 5 }).map((_, i) => (
        <Skeleton key={i} className="h-10 w-full" />
      ))}
    </div>
  )
}

function ErrorMsg() {
  return (
    <div className="rounded-md bg-red-50 px-4 py-3 text-sm text-red-700">
      Failed to load data. Please try again.
    </div>
  )
}

// ---------------------------------------------------------------------------
// Most Borrowed
// ---------------------------------------------------------------------------

function MostBorrowedSection() {
  const { isDark } = useTheme()
  const [start, setStart] = useState('')
  const [end, setEnd] = useState('')

  const params = {}
  if (start) params.start = start
  if (end) params.end = end

  const { data, isLoading, isError } = useQuery({
    queryKey: ['reports', 'most-borrowed', params],
    queryFn: async () => {
      const res = await api.get('/reports/most-borrowed', { params })
      return res.data
    },
    staleTime: 60_000,
  })

  const items = data?.items ?? []

  return (
    <SectionCard title="Most Borrowed Books">
      <div className="mb-4 flex flex-wrap items-end gap-4">
        <div>
          <label className="block text-xs font-medium text-gray-600 dark:text-slate-300">From</label>
          <input
            type="date"
            value={start}
            max={end || today()}
            onChange={(e) => setStart(e.target.value)}
            className="mt-1 rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-sm text-slate-900 shadow-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-600 dark:text-slate-300">To</label>
          <input
            type="date"
            value={end}
            min={start || undefined}
            max={today()}
            onChange={(e) => setEnd(e.target.value)}
            className="mt-1 rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-sm text-slate-900 shadow-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
          />
        </div>
        {(start || end) && (
          <Button
            size="sm"
            variant="ghost"
            onClick={() => {
              setStart('')
              setEnd('')
            }}
          >
            Clear
          </Button>
        )}
        <div className="ml-auto">
          <ExportButtons url="/reports/most-borrowed" params={params} baseName="most_borrowed" />
        </div>
      </div>

      {isLoading && <LoadingRows />}
      {isError && <ErrorMsg />}

      {!isLoading && !isError && items.length === 0 && (
        <EmptyState title="No loans found" description="No borrowing activity in the selected period." />
      )}

      {!isLoading && !isError && items.length > 0 && (
        <>
          <div className="mb-6 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={items.slice(0, 10)}
                margin={{ top: 4, right: 16, left: 0, bottom: 48 }}
              >
                <defs>
                  <linearGradient id="barBrand" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#6366f1" />
                    <stop offset="100%" stopColor="#4f46e5" />
                  </linearGradient>
                </defs>
                <CartesianGrid
                  strokeDasharray="3 3"
                  vertical={false}
                  stroke={isDark ? '#1e293b' : '#eef2f7'}
                />
                <XAxis
                  dataKey="title"
                  tick={{ fontSize: 11, fill: isDark ? '#94a3b8' : '#64748b' }}
                  angle={-35}
                  textAnchor="end"
                  interval={0}
                  tickLine={false}
                  axisLine={{ stroke: isDark ? '#334155' : '#e2e8f0' }}
                />
                <YAxis
                  allowDecimals={false}
                  tick={{ fontSize: 11, fill: isDark ? '#94a3b8' : '#64748b' }}
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip
                  cursor={{ fill: isDark ? 'rgba(148,163,184,0.08)' : 'rgba(79,70,229,0.06)' }}
                  formatter={(v) => [v, 'Borrows']}
                  contentStyle={{
                    borderRadius: 12,
                    border: `1px solid ${isDark ? '#334155' : '#e2e8f0'}`,
                    background: isDark ? '#0f172a' : '#ffffff',
                    color: isDark ? '#e2e8f0' : '#0f172a',
                    boxShadow: '0 8px 24px -6px rgba(16,24,40,0.18)',
                    fontSize: 12,
                  }}
                  labelStyle={{ color: isDark ? '#94a3b8' : '#64748b' }}
                />
                <Bar dataKey="borrow_count" fill="url(#barBrand)" radius={[6, 6, 0, 0]} maxBarSize={48} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <Table>
            <THead>
              <TR>
                <TH>#</TH>
                <TH>Title</TH>
                <TH>Author</TH>
                <TH>Borrow count</TH>
              </TR>
            </THead>
            <TBody>
              {items.map((row, idx) => (
                <TR key={row.book_id}>
                  <TD className="w-10 text-gray-400 dark:text-slate-500">{idx + 1}</TD>
                  <TD className="font-medium text-gray-900 dark:text-slate-100">{row.title}</TD>
                  <TD>{row.author}</TD>
                  <TD>
                    <Badge tone="indigo">{row.borrow_count}</Badge>
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>
        </>
      )}
    </SectionCard>
  )
}

// ---------------------------------------------------------------------------
// Overdue Members
// ---------------------------------------------------------------------------

function OverdueMembersSection() {
  const { data, isLoading, isError } = useQuery({
    queryKey: ['reports', 'overdue-members'],
    queryFn: async () => {
      const res = await api.get('/reports/overdue-members')
      return res.data
    },
    staleTime: 60_000,
  })

  const items = data?.items ?? []

  return (
    <SectionCard title="Overdue Members">
      <div className="mb-4 flex justify-end">
        <ExportButtons url="/reports/overdue-members" params={{}} baseName="overdue_members" />
      </div>

      {isLoading && <LoadingRows />}
      {isError && <ErrorMsg />}

      {!isLoading && !isError && items.length === 0 && (
        <EmptyState title="No overdue members" description="All loans are within their due dates." />
      )}

      {!isLoading && !isError && items.length > 0 && (
        <Table>
          <THead>
            <TR>
              <TH>Member</TH>
              <TH>Email</TH>
              <TH>Overdue loans</TH>
              <TH>Est. fine</TH>
            </TR>
          </THead>
          <TBody>
            {items.map((row) => (
              <TR key={row.member_id}>
                <TD className="font-medium text-gray-900 dark:text-slate-100">{row.name}</TD>
                <TD className="text-gray-500 dark:text-slate-400">{row.email}</TD>
                <TD>
                  <Badge tone="red">{row.overdue_count}</Badge>
                </TD>
                <TD className="font-semibold text-red-700 dark:text-red-400">¥{row.total_fine.toFixed(2)}</TD>
              </TR>
            ))}
          </TBody>
        </Table>
      )}
    </SectionCard>
  )
}

// ---------------------------------------------------------------------------
// Daily Transactions
// ---------------------------------------------------------------------------

function DailyTransactionsSection() {
  const [date, setDate] = useState(today())

  const { data, isLoading, isError } = useQuery({
    queryKey: ['reports', 'daily-transactions', date],
    queryFn: async () => {
      const res = await api.get('/reports/daily-transactions', { params: { date } })
      return res.data
    },
    staleTime: 30_000,
  })

  return (
    <SectionCard title="Daily Transactions">
      <div className="mb-4 flex flex-wrap items-end gap-4">
        <div>
          <label className="block text-xs font-medium text-gray-600 dark:text-slate-300">Date</label>
          <input
            type="date"
            value={date}
            max={today()}
            onChange={(e) => setDate(e.target.value)}
            className="mt-1 rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-sm text-slate-900 shadow-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
          />
        </div>
        <div className="ml-auto">
          <ExportButtons
            url="/reports/daily-transactions"
            params={{ date }}
            baseName={`daily_transactions_${date}`}
          />
        </div>
      </div>

      {isLoading && <LoadingRows />}
      {isError && <ErrorMsg />}

      {!isLoading && !isError && data && (
        <>
          <div className="mb-6 flex gap-6">
            <div className="flex-1 rounded-xl bg-brand-50 p-4 text-center ring-1 ring-brand-200 dark:bg-brand-500/10 dark:ring-brand-500/30">
              <p className="text-3xl font-bold text-brand-700 dark:text-brand-300">{data.borrowed}</p>
              <p className="mt-1 text-sm font-medium text-brand-600 dark:text-brand-400">Borrowed</p>
            </div>
            <div className="flex-1 rounded-xl bg-emerald-50 p-4 text-center ring-1 ring-emerald-200 dark:bg-emerald-500/10 dark:ring-emerald-500/30">
              <p className="text-3xl font-bold text-emerald-700 dark:text-emerald-300">{data.returned}</p>
              <p className="mt-1 text-sm font-medium text-emerald-600 dark:text-emerald-400">Returned</p>
            </div>
          </div>

          {data.borrowed_loans.length === 0 && data.returned_loans.length === 0 && (
            <EmptyState
              title="No transactions"
              description={`No loans borrowed or returned on ${fmtDate(data.date)}.`}
            />
          )}

          {data.borrowed_loans.length > 0 && (
            <div className="mb-6">
              <h3 className="mb-2 text-sm font-semibold text-gray-700 dark:text-slate-200">Borrowed</h3>
              <Table>
                <THead>
                  <TR>
                    <TH>Book</TH>
                    <TH>Member</TH>
                    <TH>Borrowed at</TH>
                    <TH>Due date</TH>
                  </TR>
                </THead>
                <TBody>
                  {data.borrowed_loans.map((row) => (
                    <TR key={row.loan_id}>
                      <TD className="font-medium text-gray-900 dark:text-slate-100">{row.book_title}</TD>
                      <TD>{row.member_name}</TD>
                      <TD>{fmtDate(row.borrowed_at)}</TD>
                      <TD>{fmtDate(row.due_date)}</TD>
                    </TR>
                  ))}
                </TBody>
              </Table>
            </div>
          )}

          {data.returned_loans.length > 0 && (
            <div>
              <h3 className="mb-2 text-sm font-semibold text-gray-700 dark:text-slate-200">Returned</h3>
              <Table>
                <THead>
                  <TR>
                    <TH>Book</TH>
                    <TH>Member</TH>
                    <TH>Returned at</TH>
                  </TR>
                </THead>
                <TBody>
                  {data.returned_loans.map((row) => (
                    <TR key={`ret-${row.loan_id}`}>
                      <TD className="font-medium text-gray-900 dark:text-slate-100">{row.book_title}</TD>
                      <TD>{row.member_name}</TD>
                      <TD>{fmtDate(row.returned_at)}</TD>
                    </TR>
                  ))}
                </TBody>
              </Table>
            </div>
          )}
        </>
      )}
    </SectionCard>
  )
}

// ---------------------------------------------------------------------------
// Page root
// ---------------------------------------------------------------------------

export default function ReportsPage() {
  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-semibold text-gray-900 dark:text-slate-100">Reports</h1>
      <MostBorrowedSection />
      <OverdueMembersSection />
      <DailyTransactionsSection />
    </div>
  )
}
