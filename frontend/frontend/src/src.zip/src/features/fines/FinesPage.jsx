import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import api from '../../lib/api'
import { useAuth } from '../../lib/auth'
import {
  Badge,
  Button,
  EmptyState,
  Pagination,
  Skeleton,
  Table,
  TBody,
  TD,
  TH,
  THead,
  TR,
  useToast,
} from '../../components/ui/index'

const PAGE_SIZE = 20

function fmtDate(iso) {
  if (!iso) return '—'
  return new Date(iso).toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  })
}

function fmtAmount(amount) {
  return `¥${parseFloat(amount).toFixed(2)}`
}

function PaidBadge({ paid }) {
  return paid ? (
    <Badge tone="green">Paid</Badge>
  ) : (
    <Badge tone="red">Unpaid</Badge>
  )
}

function FinesTable({ items, isStaff, onMarkPaid, payingId }) {
  if (items.length === 0) {
    return (
      <EmptyState
        title="No fines found"
        description="No fine records match the current filter."
      />
    )
  }

  return (
    <Table>
      <THead>
        <TR>
          {isStaff && <TH>Member</TH>}
          <TH>Book</TH>
          <TH>Due Date</TH>
          <TH>Days Overdue</TH>
          <TH>Amount</TH>
          <TH>Status</TH>
          {isStaff && <TH>Action</TH>}
        </TR>
      </THead>
      <TBody>
        {items.map((row) => (
          <TR key={row.loan_id}>
            {isStaff && (
              <TD>
                <div className="font-medium text-gray-900 dark:text-slate-100">{row.member?.name}</div>
                <div className="text-xs text-gray-500 dark:text-slate-400">{row.member?.email}</div>
              </TD>
            )}
            <TD>{row.book?.title}</TD>
            <TD>{fmtDate(row.due_date)}</TD>
            <TD>
              {row.days_overdue > 0 ? (
                <span className="font-medium text-red-600">{row.days_overdue}</span>
              ) : (
                '0'
              )}
            </TD>
            <TD>
              <span className={row.paid ? 'text-gray-500 dark:text-slate-400' : 'font-semibold text-red-700'}>
                {fmtAmount(row.amount)}
              </span>
            </TD>
            <TD>
              <PaidBadge paid={row.paid} />
            </TD>
            {isStaff && (
              <TD>
                {!row.paid && (
                  <Button
                    size="sm"
                    variant="secondary"
                    disabled={payingId === row.loan_id}
                    onClick={() => onMarkPaid(row.loan_id)}
                  >
                    {payingId === row.loan_id ? 'Saving…' : 'Mark Paid'}
                  </Button>
                )}
              </TD>
            )}
          </TR>
        ))}
      </TBody>
    </Table>
  )
}

function LoadingSkeleton() {
  return (
    <div className="space-y-2">
      {Array.from({ length: 5 }).map((_, i) => (
        <Skeleton key={i} className="h-10 w-full" />
      ))}
    </div>
  )
}

export default function FinesPage() {
  const { role } = useAuth()
  const isStaff = role === 'admin' || role === 'librarian'
  const { toast } = useToast()
  const queryClient = useQueryClient()

  const [page, setPage] = useState(1)
  const [paidFilter, setPaidFilter] = useState(isStaff ? '' : 'false')

  const queryKey = ['fines', { page, paid: paidFilter }]

  const { data, isLoading, isError } = useQuery({
    queryKey,
    queryFn: async () => {
      const params = { page, page_size: PAGE_SIZE }
      if (paidFilter !== '') params.paid = paidFilter
      const res = await api.get('/fines', { params })
      return res.data
    },
    keepPreviousData: true,
  })

  const [payingId, setPayingId] = useState(null)

  const { mutate: markPaid } = useMutation({
    mutationFn: (loanId) => api.post(`/loans/${loanId}/pay-fine`),
    onMutate: (loanId) => setPayingId(loanId),
    onSuccess: () => {
      toast({ title: 'Fine marked as paid.', tone: 'success' })
      queryClient.invalidateQueries({ queryKey: ['fines'] })
    },
    onError: () => {
      toast({ title: 'Failed to mark fine as paid.', tone: 'error' })
    },
    onSettled: () => setPayingId(null),
  })

  const items = data?.items ?? []
  const total = data?.total ?? 0
  const totalOutstanding = data?.total_outstanding ?? 0

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold text-gray-900 dark:text-slate-100">
          {isStaff ? 'Fines Dashboard' : 'My Fines'}
        </h1>
        {totalOutstanding > 0 && (
          <div className="rounded-md bg-red-50 px-4 py-2 text-sm font-medium text-red-700 ring-1 ring-inset ring-red-200">
            Total outstanding: {fmtAmount(totalOutstanding)}
          </div>
        )}
        {!isStaff && totalOutstanding === 0 && data && (
          <div className="rounded-md bg-green-50 px-4 py-2 text-sm font-medium text-green-700 ring-1 ring-inset ring-green-200">
            No outstanding balance
          </div>
        )}
      </div>

      <div className="flex items-center gap-3">
        <label className="text-sm font-medium text-gray-700 dark:text-slate-200">Filter:</label>
        <select
          value={paidFilter}
          onChange={(e) => {
            setPaidFilter(e.target.value)
            setPage(1)
          }}
          className="rounded-md border border-gray-300 dark:border-slate-700 px-3 py-1.5 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
        >
          {isStaff && <option value="">All fines</option>}
          <option value="false">Unpaid</option>
          <option value="true">Paid</option>
        </select>
      </div>

      {isLoading && <LoadingSkeleton />}

      {isError && (
        <div className="rounded-md bg-red-50 px-4 py-3 text-sm text-red-700">
          Failed to load fines. Please try again.
        </div>
      )}

      {!isLoading && !isError && (
        <>
          <FinesTable
            items={items}
            isStaff={isStaff}
            onMarkPaid={markPaid}
            payingId={payingId}
          />
          {total > PAGE_SIZE && (
            <Pagination
              page={page}
              pageSize={PAGE_SIZE}
              total={total}
              onPageChange={setPage}
            />
          )}
        </>
      )}
    </div>
  )
}
