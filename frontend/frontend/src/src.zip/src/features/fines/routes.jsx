import FinesPage from './FinesPage'

export const routes = [{ path: '/fines', element: <FinesPage /> }]
