import { useId } from 'react'

export function FormField({ label, error, children }) {
  const id = useId()
  return (
    <div>
      <label htmlFor={id} className="block text-sm font-medium text-gray-700 dark:text-slate-200">
        {label}
      </label>
      <div className="mt-1">{children({ id, invalid: Boolean(error) })}</div>
      {error ? (
        <p className="mt-1 text-xs text-red-600" role="alert">
          {error}
        </p>
      ) : null}
    </div>
  )
}
