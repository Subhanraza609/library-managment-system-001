import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../../lib/auth'
import { useToast } from '../../components/ui/Toast'
import { getApiErrorMessage } from '../../lib/apiError'
import { Button } from '../../components/ui/Button'
import { Input } from '../../components/ui/Input'
import { FormField } from './FormField'
import { AuthCard } from './AuthCard'

const schema = z
  .object({
    name: z.string().min(1, 'Name is required'),
    email: z.string().min(1, 'Email is required').email('Enter a valid email'),
    phone: z.string().optional(),
    address: z.string().optional(),
    password: z.string().min(8, 'Password must be at least 8 characters'),
    confirmPassword: z.string().min(1, 'Please confirm your password'),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: 'Passwords do not match',
    path: ['confirmPassword'],
  })

export default function RegisterPage() {
  const { register: registerUser } = useAuth()
  const { toast } = useToast()
  const navigate = useNavigate()

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({ resolver: zodResolver(schema) })

  async function onSubmit(values) {
    try {
      await registerUser({
        name: values.name,
        email: values.email,
        password: values.password,
        phone: values.phone || undefined,
        address: values.address || undefined,
      })
      toast({
        tone: 'success',
        title: 'Registration submitted',
        description: 'Your account is pending admin approval.',
      })
      navigate('/login', { replace: true })
    } catch (error) {
      toast({
        tone: 'error',
        title: 'Registration failed',
        description: getApiErrorMessage(error),
      })
    }
  }

  return (
    <AuthCard
      title="Create account"
      subtitle="Register as a member — an admin will approve your account"
      footer={
        <p className="text-sm text-gray-600 dark:text-slate-300">
          Already have an account?{' '}
          <Link to="/login" className="font-medium text-indigo-600 hover:text-indigo-500">
            Sign in
          </Link>
        </p>
      }
    >
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <FormField label="Name" error={errors.name?.message}>
          {({ id, invalid }) => (
            <Input id={id} autoComplete="name" invalid={invalid} {...register('name')} />
          )}
        </FormField>
        <FormField label="Email" error={errors.email?.message}>
          {({ id, invalid }) => (
            <Input
              id={id}
              type="email"
              autoComplete="email"
              invalid={invalid}
              {...register('email')}
            />
          )}
        </FormField>
        <FormField label="Phone (optional)" error={errors.phone?.message}>
          {({ id, invalid }) => (
            <Input id={id} autoComplete="tel" invalid={invalid} {...register('phone')} />
          )}
        </FormField>
        <FormField label="Address (optional)" error={errors.address?.message}>
          {({ id, invalid }) => (
            <Input id={id} invalid={invalid} {...register('address')} />
          )}
        </FormField>
        <FormField label="Password" error={errors.password?.message}>
          {({ id, invalid }) => (
            <Input
              id={id}
              type="password"
              autoComplete="new-password"
              invalid={invalid}
              {...register('password')}
            />
          )}
        </FormField>
        <FormField label="Confirm password" error={errors.confirmPassword?.message}>
          {({ id, invalid }) => (
            <Input
              id={id}
              type="password"
              autoComplete="new-password"
              invalid={invalid}
              {...register('confirmPassword')}
            />
          )}
        </FormField>
        <Button type="submit" className="w-full" disabled={isSubmitting}>
          {isSubmitting ? 'Submitting…' : 'Create account'}
        </Button>
      </form>
    </AuthCard>
  )
}
