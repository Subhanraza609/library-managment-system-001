import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../../lib/auth'
import { useToast } from '../../components/ui/Toast'
import { getApiErrorMessage } from '../../lib/apiError'
import { Button } from '../../components/ui/Button'
import { Input } from '../../components/ui/Input'
import { FormField } from './FormField'
import { AuthCard } from './AuthCard'

const schema = z.object({
  email: z.string().min(1, 'Email is required').email('Enter a valid email'),
  password: z.string().min(1, 'Password is required'),
})

export default function LoginPage() {
  const { login } = useAuth()
  const { toast } = useToast()
  const navigate = useNavigate()

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({ resolver: zodResolver(schema) })

  async function onSubmit(values) {
    try {
      await login(values.email, values.password)
      navigate('/dashboard', { replace: true })
    } catch (error) {
      toast({ tone: 'error', title: 'Login failed', description: getApiErrorMessage(error) })
    }
  }

  return (
    <AuthCard
      title="Sign in"
      subtitle="Welcome back to the Library Management System"
      footer={
        <p className="text-sm text-gray-600 dark:text-slate-300">
          No account?{' '}
          <Link to="/register" className="font-medium text-indigo-600 hover:text-indigo-500">
            Register
          </Link>
        </p>
      }
    >
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <FormField label="Email" error={errors.email?.message}>
          {({ id, invalid }) => (
            <Input
              id={id}
              type="email"
              autoComplete="email"
              invalid={invalid}
              {...register('email')}
            />
          )}
        </FormField>
        <FormField label="Password" error={errors.password?.message}>
          {({ id, invalid }) => (
            <Input
              id={id}
              type="password"
              autoComplete="current-password"
              invalid={invalid}
              {...register('password')}
            />
          )}
        </FormField>
        <Button type="submit" className="w-full" disabled={isSubmitting}>
          {isSubmitting ? 'Signing in…' : 'Sign in'}
        </Button>
      </form>
    </AuthCard>
  )
}
